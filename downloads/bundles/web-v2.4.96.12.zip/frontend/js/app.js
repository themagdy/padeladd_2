var FX={ignite:function(e){e&&(e.classList.remove("ignite"),e.offsetWidth,e.classList.add("ignite"),setTimeout(()=>{e.classList.remove("ignite")},650))}},SoundManager={_ctx:null,_buffers:{},_unlocked:!1,_initialized:!1,init:function(){if(this._initialized)return;this._initialized=!0;const e=()=>{if(this._unlocked)return;const t=window.AudioContext||window.webkitAudioContext;if(t){this._ctx=new t;const i={tap:"assets/sounds/tap.mp3",success:"assets/sounds/success.mp3",notify:"assets/sounds/notify.mp3"};for(const[s,a]of Object.entries(i))fetch(a).then(r=>r.arrayBuffer()).then(r=>this._ctx.decodeAudioData(r)).then(r=>{this._buffers[s]=r}).catch(r=>console.warn("[SoundManager] Load failed:",a,r));this._ctx.state==="suspended"&&this._ctx.resume();const n=this._ctx.createBufferSource();n.buffer=this._ctx.createBuffer(1,1,22050),n.connect(this._ctx.destination),n.start(0)}this._unlocked=!0,["touchstart","click","mousedown"].forEach(i=>document.removeEventListener(i,e))};["touchstart","click","mousedown"].forEach(t=>document.addEventListener(t,e,{passive:!0})),document.addEventListener("click",t=>{const i=t.target.closest("button, a, .nav-item, [onclick], .clickable");i&&!i.hasAttribute("data-no-sound")&&this.play("tap");const n=t.target.closest(".stat-box");n&&(n.classList.remove("clicked"),n.offsetWidth,n.classList.add("clicked"),setTimeout(()=>n.classList.remove("clicked"),600))},!0)},play:function(e){if(!this._ctx||!this._buffers[e])return;this._ctx.state==="suspended"&&this._ctx.resume();const t=this._ctx.createBufferSource();t.buffer=this._buffers[e],t.connect(this._ctx.destination),t.start(0);const i=window.Capacitor?.Plugins?.Haptics;i&&(e==="tap"?i.selectionChanged().catch(()=>{}):e==="success"&&i.notification({type:"SUCCESS"}).catch(()=>{}))}},Toast={show:function(e,t="info",i=5e3){let n=document.getElementById("toast-container");n||(n=document.createElement("div"),n.id="toast-container",document.body.appendChild(n));const s=document.createElement("div");s.className=`toast ${t}`;let a="\u{1F514}";t==="success"&&(a="\u2705"),t==="error"&&(a="\u26A0\uFE0F"),t==="warning"&&(a="\u26A0\uFE0F"),s.innerHTML=safeHTML(`
            <span class="toast-icon">${a}</span>
            <span class="toast-message">${e}</span>
            <button class="toast-close" onclick="this.parentElement.remove()">\u2715</button>
        `),n.appendChild(s),i>0&&setTimeout(()=>{s.parentElement&&(s.style.opacity="0",s.style.transform="translateY(-20px)",setTimeout(()=>{s.parentElement&&s.remove()},300))},i)}},ConfirmModal={_modal:null,_resolve:null,_isOpen:!1,show:function({title:e,message:t,confirmText:i="Confirm",cancelText:n="Cancel",showCancel:s=!0,thirdText:a=null,thirdColor:r="var(--c-secondary)",type:c="info",showInput:f=!1,inputType:o="textarea",required:p=!1,inputPlaceholder:k="Enter reason...",inputMaxLength:v=300,tipText:E="",icon:P=null,undismissable:B=!1,closeOnOverlayClick:I=!0,headerLayout:N="column",playersList:b=null}){return new Promise(O=>{this._resolve=O,this._undismissable=B,this._closeOnOverlayClick=I,this._modal||(this._modal=document.createElement("div"),this._modal.id="global-confirm-modal",this._modal.style.cssText=`
                    position:fixed; top:0; left:0; width:100%; height:100%;
                    background:rgba(0,0,0,0.8);
                    display:flex; flex-direction:column; align-items:center; justify-content:flex-start;
                    z-index:100000; opacity:0; pointer-events:none;
                    transition:opacity 0.25s ease; padding:32px 16px;
                    overflow-y:auto;
                `,document.body.appendChild(this._modal));const l=c==="warning",d=P??(l?"\u26A1":""),m=l?"var(--c-red)":"var(--c-primary)";let g="";if(f)if(o==="radio"){let u='<option value="" disabled selected hidden>Select Player</option>';b&&Array.isArray(b)&&b.forEach(h=>{u+=`<option value="${h.id}">${h.name}</option>`}),g=`
                        <div id="gcm-radio-container" style="margin-bottom:4px; width:100%; display:flex; flex-direction:column; align-items:flex-start;">
                            <label style="display:flex; align-items:center; gap:10px; margin-bottom:12px; cursor:pointer; color:#fff; font-size:14px; font-weight:600; text-align:left; width:100%;">
                                <input type="radio" name="gcm-radio-opt" value="No show" style="accent-color:var(--c-primary); width:18px; height:18px; cursor:pointer;" />
                                <span>No show</span>
                            </label>
                            
                            <label style="display:flex; align-items:center; gap:10px; margin-bottom:12px; cursor:pointer; color:#fff; font-size:14px; font-weight:600; text-align:left; width:100%;">
                                <input type="radio" name="gcm-radio-opt" value="Level mismatch" style="accent-color:var(--c-primary); width:18px; height:18px; cursor:pointer;" />
                                <span>Level mismatch</span>
                            </label>
                            
                            <label style="display:flex; align-items:center; gap:10px; margin-bottom:12px; cursor:pointer; color:#fff; font-size:14px; font-weight:600; text-align:left; width:100%;">
                                <input type="radio" name="gcm-radio-opt" value="Bad attitude" style="accent-color:var(--c-primary); width:18px; height:18px; cursor:pointer;" />
                                <span>Bad attitude</span>
                            </label>

                            ${b&&Array.isArray(b)?`
                            <div id="gcm-radio-player-wrap" style="display:none; margin-bottom:8px; width:100%; padding-left:28px; box-sizing:border-box;">
                                <label style="color:rgba(255,255,255,0.6); display:block; text-align:left; font-size:11px; font-weight:800; text-transform:uppercase; margin-bottom:6px; font-family:var(--font);">Select Player</label>
                                <select id="gcm-player-select" style="width:100%; border:1px solid rgba(255,255,255,0.15); background:rgba(23, 23, 28, 0.98) url(&quot;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='%238B9BB4' stroke-width='2'%3E%3Cpath d='M6 9l6 6 6-6'/%3E%3C/svg%3E&quot;) no-repeat right 16px center; appearance:none; -webkit-appearance:none; color:#fff; border-radius:12px; padding:14px 44px 14px 16px; font-size:14px; font-family:var(--font); outline:none; cursor:pointer;">
                                    ${u}
                                </select>
                            </div>
                            `:""}

                            <label style="display:flex; align-items:center; gap:10px; margin-bottom:12px; cursor:pointer; color:#fff; font-size:14px; font-weight:600; text-align:left; width:100%;">
                                <input type="radio" name="gcm-radio-opt" value="other" style="accent-color:var(--c-primary); width:18px; height:18px; cursor:pointer;" />
                                <span>Other</span>
                            </label>

                            <div id="gcm-radio-other-wrap" style="display:none; margin-bottom:8px; width:100%; padding-left:28px; box-sizing:border-box;">
                                <textarea id="gcm-input" placeholder="Please describe the issue..." maxlength="${v}" style="width:100%; border:1px solid rgba(255,255,255,0.15); background:rgba(255,255,255,0.06); color:#fff; border-radius:12px; padding:12px; font-size:14px; resize:none; font-family:var(--font); outline:none; margin-bottom:4px;" rows="3"></textarea>
                                <div style="display:flex; justify-content:space-between; margin-bottom:0; padding:0 4px;">
                                    <span id="gcm-tip" style="font-size:11px; color:var(--c-text-dim); text-align:left; flex:1; padding-right:10px;">${E}</span>
                                    <span id="gcm-counter" style="font-size:11px; color:var(--c-text-muted); font-weight:700; white-space:nowrap;">0/${v}</span>
                                </div>
                            </div>
                        </div>
                    `}else g=`
                        <${o==="textarea"?"textarea":"input"} id="gcm-input" type="${o}" placeholder="${k}" maxlength="${v}" style="width:100%; border:1px solid rgba(255,255,255,0.15); background:rgba(255,255,255,0.06); color:#fff; border-radius:12px; padding:12px; font-size:14px; margin-bottom:${o==="password"?"18px":"4px"}; resize:none; font-family:var(--font); outline:none;" ${o==="textarea"?'rows="6"':""}></${o==="textarea"?"textarea":"input"}>
                    `;f&&o!=="radio"&&(g+=`
                    <div style="display:${o==="password"?"none":"flex"}; justify-content:space-between; margin-bottom:24px; padding:0 4px;">
                        <span id="gcm-tip" style="font-size:11px; color:var(--c-text-dim); text-align:left; flex:1; padding-right:10px;">${E}</span>
                        <span id="gcm-counter" style="font-size:11px; color:var(--c-text-muted); font-weight:700; white-space:nowrap;">0/${v}</span>
                    </div>
                `);const z=a?`
                <button id="gcm-third" class="btn" style="background:${r}; color:white; border:none; padding:16px;">${a}</button>
            `:"",L=s?`
                <button id="gcm-cancel" class="btn" style="background:none; border:none; color:var(--c-text-muted); padding:12px; font-size:14px; font-weight:600;">${n}</button>
            `:"";let S="";if(N==="row")S=`
                    <div style="display:flex; align-items:flex-end; justify-content:flex-start; gap:10px; margin-bottom:16px; padding-bottom:16px; border-bottom:1px solid rgba(255,255,255,0.08);">
                        ${d?`<div style="font-size:24px; line-height:1;">${d}</div>`:""}
                        <h2 style="font-size:15px; font-weight:800; color:#fff; margin:0; text-transform:uppercase; letter-spacing:0.5px; line-height:1; padding-bottom:2px; text-align:left;">${e}</h2>
                    </div>
                `;else{let u="";d&&(u=`
                    <!-- Premium Emoji Frame -->
                    <div style="margin: 0 auto 20px; width:72px; height:72px; position:relative; display:flex; align-items:center; justify-content:center;">
                        <div style="position:absolute; inset:0; border-radius:50%; background:linear-gradient(135deg, var(--c-primary), #6366f1); opacity:0.15; filter:blur(10px);"></div>
                        <div style="position:absolute; inset:0; border-radius:50%; border:1px solid rgba(255,255,255,0.1); background:rgba(255,255,255,0.03);"></div>
                        <div style="font-size:34px; z-index:1; filter: drop-shadow(0 4px 10px rgba(0,0,0,0.3));">${d}</div>
                    </div>`),S=`
                    ${u}
                    <h2 style="font-size:22px; font-weight:700; background: linear-gradient(135deg, #ffffff 0%, #a5b4fc 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; margin-bottom:20px; letter-spacing:-0.5px; line-height:1.2; text-align:${d?"center":"left"};">${e}</h2>
                `}const y=N==="row",A=y?"380px":"340px",C=y?"20px":"28px",T=y?"24px":"32px";if(this._modal.innerHTML=safeHTML(`
                <div id="gcm-card" style="margin: auto 0; flex-shrink: 0; background:rgba(23, 23, 28, 0.98); backdrop-filter:blur(8px); border:1px solid rgba(255,255,255,0.1); border-radius:${T}; padding:${C}; width:100%; max-width:${A}; text-align:center; position:relative; transform:scale(0.85); opacity:0; transition:all 0.4s cubic-bezier(0.16, 1, 0.3, 1); box-shadow:0 30px 60px rgba(0,0,0,0.6);">
                    
                    ${S}
                    
                    ${g}
 
                    ${t?`<div style="font-size:12px; color:rgba(255,255,255,0.5); line-height:1.6; margin-bottom:24px; font-weight:400; text-align:left; padding:0;">${t.replace(/\n/g,"<br>")}</div>`:""}
 
                    <div style="display:flex; gap:12px; flex-direction:column;">
                        <button id="gcm-confirm" class="btn" style="background:var(--c-primary); color:#fff; border:none; width:100%; padding:14px; border-radius:16px; font-weight:800; font-size:14px; letter-spacing:0.5px; box-shadow: 0 8px 20px rgba(27, 82, 206, 0.25); transition:transform 0.2s;">
                            ${i.toUpperCase()}
                        </button>
                        ${z}
                        ${L}
                    </div>
                </div>
            `),this._modal.onclick=u=>{u.target===this._modal&&!this._undismissable&&this._closeOnOverlayClick&&this.close(!1)},this._modal.querySelector("#gcm-confirm").onclick=()=>{let u=null;if(f)if(o==="radio"){const h=this._modal.querySelector('input[name="gcm-radio-opt"]:checked');if(!h){Toast.show("Please select an option.","error");return}const _=h.value;if(_==="other"){const x=this._modal.querySelector("#gcm-input").value.trim();if(x===""){this._modal.querySelector("#gcm-input").style.borderColor="var(--c-red)",Toast.show("Please describe the issue.","error");return}u="Other: "+x}else{if(b&&Array.isArray(b)){const x=this._modal.querySelector("#gcm-player-select");if(!x||x.value===""){Toast.show("Please select a player.","error");return}}u=_}}else{const h=this._modal.querySelector("#gcm-input").value.trim();if(p&&h===""){const _=this._modal.querySelector("#gcm-input");_.style.borderColor="var(--c-red)";const x=o==="password"?"Please enter your password.":"Please enter a message.";Toast.show(x,"error");return}u=h}else u=!0;if(b&&Array.isArray(b)){const h=this._modal.querySelector('input[name="gcm-radio-opt"]:checked'),_=h&&h.value==="other",x=this._modal.querySelector("#gcm-player-select"),$=!_&&x?parseInt(x.value):null;this.close({reason:u,targetUserId:$})}else this.close(u)},f){const u=this._modal.querySelector("#gcm-input"),h=this._modal.querySelector("#gcm-counter");if(o==="radio"){const _=this._modal.querySelectorAll('input[name="gcm-radio-opt"]'),x=this._modal.querySelector("#gcm-radio-other-wrap"),$=this._modal.querySelector("#gcm-radio-player-wrap");_.forEach(R=>{R.onchange=()=>{const H=R.closest("label");R.value==="other"?(x.style.display="block",$&&($.style.display="none"),setTimeout(()=>u.focus(),100)):(x.style.display="none",$&&($.style.display="block",H.parentNode.insertBefore($,H.nextSibling)))}})}u.oninput=()=>{h&&(h.innerText=`${u.value.length}/${v}`),u.style.borderColor="var(--c-border)"},o!=="radio"&&setTimeout(()=>u.focus(),300)}a&&(this._modal.querySelector("#gcm-third").onclick=()=>this.close("third"));const w=this._modal.querySelector("#gcm-cancel");w&&(w.onclick=()=>this.close(!1));const M=window.scrollY||document.documentElement.scrollTop;document.documentElement.style.overflow="hidden",document.body.style.overflow="hidden",document.body.style.position="fixed",document.body.style.top=`-${M}px`,document.body.style.width="100%",this._isOpen=!0,this._modal.style.opacity="1",this._modal.style.pointerEvents="auto",setTimeout(()=>{const u=document.getElementById("gcm-card");u&&(u.style.transform="scale(1)",u.style.opacity="1")},10)})},close:function(e){if(!this._modal)return;if(this._undismissable){if(this._resolve){const n=this._resolve;this._resolve=null,n(e)}return}const t=parseFloat(document.body.style.top||"0")*-1;document.documentElement.style.overflow="",document.body.style.overflow="",document.body.style.touchAction="",document.body.style.position="",document.body.style.top="",document.body.style.width="",this._modal.ontouchmove=null,t>0&&window.scrollTo(0,t),this._isOpen=!1,this._modal.style.opacity="0",this._modal.style.pointerEvents="none";const i=document.getElementById("gcm-card");i&&(i.style.transform="scale(0.95)",i.style.opacity="0"),setTimeout(()=>{this._resolve&&this._resolve(e)},250)}},InviteModal={_modal:null,_isOpen:!1,show:function(e,t){this._modal||(this._modal=document.createElement("div"),this._modal.id="invite-modal-overlay",this._modal.style.cssText=`
                position:fixed; top:0; left:0; width:100%; height:100%;
                background:rgba(0,0,0,0.8);
                display:flex; flex-direction:column; align-items:center; justify-content:flex-start;
                z-index:100000; opacity:0; pointer-events:none;
                transition:opacity 0.25s ease; padding:32px 16px;
                overflow-y:auto;
            `,document.body.appendChild(this._modal));const i=e.map((s,a)=>{const r=!!s.used_at;let c="";if(r){let f="?";s.used_by_name&&(f=s.used_by_name.substring(0,2).toUpperCase()),c=`
                    <div style="display:flex; align-items:center; gap:10px; width:100%;">
                        ${UI.getAvatarHtml(s.used_by_avatar,"width:100%; height:100%; border-radius:50%; object-fit:cover;","width:32px; height:32px; border-radius:50%; flex-shrink:0; font-size:11px; font-weight:700; display:flex; align-items:center; justify-content:center; background:rgba(255,255,255,0.06); color:#fff;",f)}
                        <div style="flex:1; text-align:left; min-width:0;">
                            <div style="font-weight:700; font-size:13px; color:#fff; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">Used by ${s.used_by_name}</div>
                            <div style="font-size:10px; color:var(--c-orange); font-weight:800; font-family:monospace; margin-top:2px;">CODE: ${s.code}</div>
                        </div>
                        <span style="font-size:18px; color:var(--c-green); flex-shrink:0;">\u2713</span>
                    </div>
                `}else c=`
                    <div style="display:flex; align-items:center; justify-content:space-between; width:100%;">
                        <span style="font-family: 'JetBrains Mono', monospace; font-size:15px; font-weight:800; color:#fff; letter-spacing:0.5px;">${s.code}</span>
                        <button onclick="InviteModal.copyCode('${s.code}', this)" class="btn btn-sm" style="background:rgba(255,255,255,0.05); color:#fff; border:1px solid rgba(255,255,255,0.1); padding:6px 14px; border-radius:8px; font-size:11px; font-weight:700; transition:all 0.2s; cursor:pointer;" onmouseover="this.style.background='rgba(255,255,255,0.1)'" onmouseout="this.style.background='rgba(255,255,255,0.05)'">
                            COPY
                        </button>
                    </div>
                `;return`
                <div style="display:flex; align-items:center; background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); border-radius:16px; padding:14px 18px; margin-bottom:12px; transition:all 0.2s;">
                    ${c}
                </div>
            `}).join("");this._modal.innerHTML=safeHTML(`
             <div id="invite-modal-card" style="margin: auto 0; background:rgba(23, 23, 28, 0.98); backdrop-filter:blur(8px); border:1px solid rgba(255,255,255,0.1); border-radius:32px; padding:28px; width:100%; max-width:340px; text-align:center; position:relative; transform:scale(0.85); opacity:0; transition:all 0.4s cubic-bezier(0.16, 1, 0.3, 1); box-shadow:0 30px 60px rgba(0,0,0,0.6);">
                <div style="margin: 0 auto 20px; width:72px; height:72px; position:relative; display:flex; align-items:center; justify-content:center;">
                    <div style="position:absolute; inset:0; border-radius:50%; background:linear-gradient(135deg, var(--c-orange), #ff8b00); opacity:0.15; filter:blur(10px);"></div>
                    <div style="position:absolute; inset:0; border-radius:50%; border:1px solid rgba(255,255,255,0.1); background:rgba(255,255,255,0.03);"></div>
                    <div style="font-size:34px; z-index:1; filter: drop-shadow(0 4px 10px rgba(0,0,0,0.3));">\u{1F39F}\uFE0F</div>
                </div>
                <h2 style="font-size:20px; font-weight:900; color:#fff; margin-bottom:8px; letter-spacing:-0.5px; line-height:1.2;">Exclusive Invites</h2>
                <p style="font-size:12px; color:var(--c-text-muted); line-height:1.6; margin-bottom:24px; font-weight:400; padding:0 8px; text-align:center;">
                    Your friends need one of these exclusive codes to register. Give them out wisely!
                </p>

                <div style="margin-bottom:24px;">
                    ${i}
                </div>

                <div>
                    <button onclick="InviteModal.close()" class="btn" style="background:var(--c-primary); color:#fff; border:none; width:100%; padding:14px; border-radius:16px; font-weight:800; font-size:14px; letter-spacing:0.5px; box-shadow: 0 8px 20px rgba(27, 82, 206, 0.25); transition:transform 0.2s;">
                        CLOSE
                    </button>
                </div>
            </div>
        `),this._modal.onclick=s=>{s.target===this._modal&&this.close()};const n=window.scrollY||document.documentElement.scrollTop;document.documentElement.style.overflow="hidden",document.body.style.overflow="hidden",document.body.style.position="fixed",document.body.style.top=`-${n}px`,document.body.style.width="100%",this._isOpen=!0,this._modal.style.opacity="1",this._modal.style.pointerEvents="auto",setTimeout(()=>{const s=document.getElementById("invite-modal-card");s&&(s.style.transform="scale(1)",s.style.opacity="1")},10)},copyCode:function(e,t){if(!navigator.clipboard){const i=document.createElement("textarea");i.value=e,i.style.position="fixed",document.body.appendChild(i),i.focus(),i.select();try{document.execCommand("copy"),this.onCopySuccess(t)}catch(n){console.error("Fallback copy failed",n)}document.body.removeChild(i);return}navigator.clipboard.writeText(e).then(()=>{this.onCopySuccess(t)}).catch(i=>{console.error("Clipboard copy failed",i)})},onCopySuccess:function(e){if(e){const t=e.textContent;e.textContent="COPIED!",e.style.borderColor="var(--c-green)",e.style.color="var(--c-green)",e.style.background="rgba(16,185,129,0.1)",setTimeout(()=>{e.textContent=t,e.style.borderColor="rgba(255,255,255,0.1)",e.style.color="#fff",e.style.background="rgba(255,255,255,0.05)"},2e3)}Toast.show("Invitation code copied to clipboard!","success")},close:function(){if(!this._modal)return;const e=parseFloat(document.body.style.top||"0")*-1;document.documentElement.style.overflow="",document.body.style.overflow="",document.body.style.touchAction="",document.body.style.position="",document.body.style.top="",document.body.style.width="",e>0&&window.scrollTo(0,e),this._isOpen=!1,this._modal.style.opacity="0",this._modal.style.pointerEvents="none";const t=document.getElementById("invite-modal-card");t&&(t.style.transform="scale(0.95)",t.style.opacity="0")}},PollManager={_timer:null,_activeTask:null,start:function(e,t,i=15e3){this.stop(),this._activeTask=e,this._timer=setInterval(()=>{console.log(`[PollManager] Running: ${e}`),t()},i)},stop:function(){this._timer&&(console.log(`[PollManager] Stopping: ${this._activeTask}`),clearInterval(this._timer),this._timer=null,this._activeTask=null)}},PushNotificationsController={_isStartingUp:!0,init:async function(){const e=window.Capacitor?.Plugins?.PushNotifications;if(!e){console.log("[PushNotifications] Not a native app or plugin missing");return}setTimeout(()=>{this._isStartingUp=!1,console.log("[PushNotifications] Startup silence period ended")},3e3),await new Promise(t=>setTimeout(t,2e3));try{console.log("[PushNotifications] Starting registration flow...");let t=await e.checkPermissions();if(console.log("[PushNotifications] Permission status:",t.receive),t.receive==="prompt"&&(t=await e.requestPermissions()),t.receive!=="granted"){console.log("[PushNotifications] Permission not granted");return}console.log("[PushNotifications] Registering..."),await e.register(),this.setupListeners(e)}catch(t){console.error("[PushNotifications] Initialization crash prevented:",t)}},setupListeners:function(e){if(e)try{e.addListener("registration",t=>{console.log("[PushNotifications] Registration success"),this.updateServerToken(t.value)}),e.addListener("registrationError",t=>{console.error("[PushNotifications] Registration error:",t.error)}),e.addListener("pushNotificationReceived",t=>{console.log("[PushNotifications] Received in foreground:",t),t.title&&t.body&&(Toast.show(t.body,"info"),typeof SoundManager<"u"&&!this._isStartingUp&&SoundManager.play("notify"),typeof Router<"u"&&Router.currentPath==="/dashboard"&&typeof DashboardController<"u"&&DashboardController.load())}),e.addListener("pushNotificationActionPerformed",t=>{console.log("[PushNotifications] Action performed. App opened via notification.")})}catch(t){console.error("[PushNotifications] Listener setup failed:",t)}},updateServerToken:async function(e){if(typeof Auth<"u"&&!Auth.isAuthenticated())return;const t=window.Capacitor?.getPlatform?.()||"web";console.log("[PushNotifications] Updating server token..."),await API.post("/profile/update_device_token",{token:e,platform:t})}};const InAppMessagesController={init:async function(){Auth.isAuthenticated()&&this.check()},check:async function(){try{const e=await API.get("/system/check_in_app_messages?t="+Date.now());e.success&&e.data&&this.display(e.data)}catch(e){console.error("[InAppMessages] Check failed:",e)}},display:async function(e){let t=e.button_text||"Got it",i=e.action_type;ConfirmModal.show({title:e.heading,message:e.body,icon:e.emoji,confirmText:t,showCancel:!1,type:"info",undismissable:e.is_undismissable==1,closeOnOverlayClick:!1}).then(async n=>{if(await API.post("/system/mark_message_seen",{message_id:e.id}),!!n){if(i==="navigate"&&e.page_route)Router.navigate(e.page_route);else if(i==="external"){const s=window.Capacitor?.getPlatform?.()||"web";let a=e.android_url;s==="ios"&&(a=e.ios_url||e.android_url),a&&window.open(a,"_blank")}}})}},ScoreUI={renderMatchScore:function(e,t=null,i=null,n=!0,s=null){if(!t&&e.scores&&(t=e.scores.find(l=>l.status==="approved")),!t)return"";const a=[];let r=0,c=0;for(let l=1;l<=3;l++){const d=parseInt(t[`t1_set${l}`]),m=parseInt(t[`t2_set${l}`]);if(isNaN(d)||isNaN(m)||l>1&&d===0&&m===0)continue;const g=d>m?1:m>d?2:0;g===1?r++:g===2&&c++,a.push({s1:d,s2:m,winner:g})}const f=r>c;let o=[],p=[];const k=i||[...e.team_a||[],...e.team_b||[]];let v=null;if(t.composition_json)try{v=typeof t.composition_json=="string"?JSON.parse(t.composition_json):t.composition_json}catch{}v&&v.length>0?v.forEach(l=>{const d=k.find(g=>parseInt(g.user_id||g.id)===parseInt(l.user_id)),m={name:l.nickname||l.name||(d?d.nickname||d.name||d.first_name+" "+d.last_name:"\u2014"),code:l.player_code||l.code||(d?d.player_code||d.code:""),team_no:parseInt(l.team_no),user_id:parseInt(l.user_id),point_change:d?.point_change??null};m.team_no===1?o.push(m):m.team_no===2&&p.push(m)}):k.forEach(l=>{const d={name:l.nickname||l.name||l.first_name+" "+l.last_name||"\u2014",code:l.player_code||l.code||"",team_no:parseInt(l.team_no),user_id:parseInt(l.user_id||l.id),point_change:l.point_change??null};d.team_no===1?o.push(d):d.team_no===2&&p.push(d)});const E=(l,d)=>{const m=l[0]||{name:"\u2014"},g=l[1]||{name:"\u2014"},z=e.match_type==="friendly",L=z?"#5A91FF":"var(--c-orange)",S=y=>{let A="";const C=t?.point_changes?.[y.user_id]??t?.point_changes?.[String(y.user_id)],T=C??y.point_change;if(s&&parseInt(y.user_id)===parseInt(s)&&T!==null&&T!==void 0){const w=parseInt(T);if(w!==0&&!isNaN(w)){const M=w>0?"#064e3b":"#450a0a",u=w>0?"#4ade80":"#f87171",h=w>0?"1px solid rgba(74,222,128,0.4)":"1px solid rgba(248,113,113,0.4)",_=w>0?"\u2191":"\u2193";A=`<span style="font-size:10px; font-weight:700; letter-spacing:0.3px; background:${M}; color:${u}; padding:0 6px; border-radius:10px; border:${h}; box-shadow:0 2px 6px rgba(0,0,0,0.4); white-space:nowrap; display:inline-flex; align-items:center; height:18px; line-height:1; margin-left:3px; vertical-align:middle;"><span style="font-size:11px; margin-right:2px; font-weight:800;">${_}</span>${Math.abs(w)}</span>`}}return`<span class="msc-premium-player-name">${y.name}</span>${A}`};return`
                <div class="msc-premium-row" style="opacity:${d?"1":"0.85"}; background:${d?z?"rgba(90,145,255,0.06)":"rgba(247,148,29,0.06)":"transparent"};">
                    <div class="msc-premium-players" style="font-weight:${d?"700":"400"}; color:${d?"#fff":"rgba(255,255,255,0.8)"};">
                        ${S(m)}
                        <span style="opacity:0.25; margin:0 4px;">/</span>
                        ${S(g)}
                    </div>
                    <div class="msc-premium-scores">
                        ${a.map(y=>{const A=y.winner===(l===o?1:2),C=l===o?y.s1:y.s2;return`
                                <span class="msc-premium-score-val" style="color:${A?L:"rgba(255,255,255,0.35)"};">
                                    ${C}
                                </span>
                            `}).join("")}
                    </div>
                </div>
            `},P=(e.venue||"Venue TBD").split(" - ")[0].trim(),B=e.scheduled_at?new Date(e.scheduled_at.replace(" ","T")).toLocaleDateString("en-US",{weekday:"short",day:"numeric",month:"short"}):"",I=e.match_type==="friendly",b=n?`
            <div class="msc-premium-header">
                <span class="msc-premium-venue-date">${P} \u2022 ${B}</span>
                <span class="msc-premium-type-badge" style="color:${I?"#5A91FF":"var(--c-orange)"};">
                    ${I?"\u{1F91D} Friendly":"\u{1F3C6} Competition"}
                </span>
            </div>
        `:"",O=I?"#5A91FF":"var(--c-orange)";return`
            <div class="msc-premium-card">
                ${b}
                <div class="msc-premium-body">
                    ${E(o,f)}
                    ${E(p,!f)}
                </div>
            </div>
        `},renderSkeleton:function(e=3){let t="";for(let i=0;i<e;i++)t+=`
                <div style="margin-bottom:12px; padding:16px; background:rgba(255,255,255,0.02); border-radius:var(--r-lg); border:1px solid rgba(255,255,255,0.05); overflow:hidden;">
                    <div style="display:flex; align-items:center; gap:8px; margin-bottom:16px; padding:0 4px;">
                        <div class="skeleton" style="width:80px; height:10px; border-radius:4px; opacity:0.6;"></div>
                        <div style="width:4px; height:4px; border-radius:50%; background:var(--c-border); opacity:0.3;"></div>
                        <div class="skeleton" style="width:60px; height:10px; border-radius:4px; opacity:0.4;"></div>
                    </div>
                    <div style="display:flex; flex-direction:column; gap:8px;">
                        <div style="display:flex; justify-content:space-between; align-items:center; background:rgba(255,255,255,0.01); padding:10px 12px; border-radius:10px; border:1px solid rgba(255,255,255,0.02);">
                            <div style="display:flex; align-items:center; gap:8px;">
                                <div style="width:10px; height:10px; border-radius:2px; background:var(--c-border); opacity:0.2;"></div>
                                <div style="display:flex; gap:6px;">
                                    <div class="skeleton" style="width:90px; height:12px; border-radius:4px;"></div>
                                    <div class="skeleton" style="width:36px; height:12px; border-radius:4px; opacity:0.5;"></div>
                                </div>
                            </div>
                            <div style="display:flex; gap:10px;">
                                <div class="skeleton" style="width:14px; height:16px; border-radius:4px; opacity:0.8;"></div>
                                <div class="skeleton" style="width:14px; height:16px; border-radius:4px; opacity:0.4;"></div>
                            </div>
                        </div>
                        <div style="display:flex; justify-content:space-between; align-items:center; background:rgba(255,255,255,0.01); padding:10px 12px; border-radius:10px; border:1px solid rgba(255,255,255,0.02);">
                            <div style="display:flex; align-items:center; gap:8px;">
                                <div style="width:10px; height:10px; border-radius:2px; background:transparent;"></div>
                                <div style="display:flex; gap:6px;">
                                    <div class="skeleton" style="width:110px; height:12px; border-radius:4px;"></div>
                                    <div class="skeleton" style="width:36px; height:12px; border-radius:4px; opacity:0.5;"></div>
                                </div>
                            </div>
                            <div style="display:flex; gap:10px;">
                                <div class="skeleton" style="width:14px; height:16px; border-radius:4px; opacity:0.4;"></div>
                                <div class="skeleton" style="width:14px; height:16px; border-radius:4px; opacity:0.8;"></div>
                            </div>
                        </div>
                    </div>
                </div>
            `;return t}},RankingUI={renderSkeleton:function(e=5){let t="";for(let i=0;i<e;i++)t+=`
                <div style="padding:14px 10px; display:grid; grid-template-columns: 40px 1fr 60px; align-items:center; gap:12px; border-bottom:1px solid rgba(255,255,255,0.05); overflow:hidden;">
                    <div style="display:flex; justify-content:center;">
                        <div class="skeleton" style="width:24px; height:24px; border-radius:50%; opacity:0.3;"></div>
                    </div>
                    <div style="display:flex; align-items:center; gap:12px;">
                        <div class="skeleton" style="width:36px; height:36px; border-radius:50%; flex-shrink:0;"></div>
                        <div style="display:flex; flex-direction:column; gap:6px; flex:1;">
                            <div class="skeleton" style="width:120px; height:12px; border-radius:4px;"></div>
                            <div class="skeleton" style="width:80px; height:10px; border-radius:4px; opacity:0.5;"></div>
                        </div>
                    </div>
                    <div style="display:flex; justify-content:flex-end;">
                        <div class="skeleton" style="width:40px; height:14px; border-radius:4px;"></div>
                    </div>
                </div>
            `;return t}},StatsUI={update:function(e,t){if(!e)return;const i=()=>{const o=document.createElementNS("http://www.w3.org/2000/svg","svg");o.setAttribute("width","12"),o.setAttribute("height","12"),o.setAttribute("viewBox","0 0 24 24"),o.setAttribute("fill","none"),o.setAttribute("stroke","currentColor"),o.setAttribute("stroke-width","4"),o.setAttribute("stroke-linecap","round"),o.setAttribute("stroke-linejoin","round");const p=document.createElementNS("http://www.w3.org/2000/svg","polyline");return p.setAttribute("points","18 15 12 9 6 15"),o.appendChild(p),o},n=()=>{const o=document.createElementNS("http://www.w3.org/2000/svg","svg");o.setAttribute("width","12"),o.setAttribute("height","12"),o.setAttribute("viewBox","0 0 24 24"),o.setAttribute("fill","none"),o.setAttribute("stroke","currentColor"),o.setAttribute("stroke-width","4"),o.setAttribute("stroke-linecap","round"),o.setAttribute("stroke-linejoin","round");const p=document.createElementNS("http://www.w3.org/2000/svg","polyline");return p.setAttribute("points","6 9 12 15 18 9"),o.appendChild(p),o},s={ranking:e.ranking??"\u2014",points:e.points,matches:e.matches_played,winrate:e.win_rate+"%"};for(const[o,p]of Object.entries(s)){const k=document.getElementById(`${t}-${o}`)||document.getElementById(`${t}-${o}-count`);k&&(k.innerHTML="",k.textContent=p)}const a=document.getElementById(`${t}-ranking-change`)||document.getElementById(`${t}-highest-rank`);if(a){a.innerHTML="";const o=document.createElement("span");e.ranking_change>0?(o.className="stat-trend up",o.appendChild(i()),o.append(` ${e.ranking_change} POSITIONS`)):e.ranking_change<0?(o.className="stat-trend down",o.appendChild(n()),o.append(` ${Math.abs(e.ranking_change)} POSITIONS`)):(o.className="stat-trend neutral",o.textContent="STABLE RANK"),a.appendChild(o)}const r=document.getElementById(`${t}-points-week`);if(r){r.innerHTML="";const o=e.current_buffer??0;if(o>0){const p=document.createElement("span");p.style.cssText="color: var(--c-orange); background: rgba(255, 139, 0, 0.12); border: 1px solid rgba(255, 139, 0, 0.25); padding: 3px 8px; border-radius: 6px; display: inline-flex; align-items: baseline; gap: 6px;",p.innerHTML=`<span style="font-size: 13px; font-weight: 800;">+${o}</span><span style="font-size: 9px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px;">BUFFER</span>`,r.appendChild(p),r.style.color=""}else if(e.points_this_week!==void 0){if(e.points_this_week>0){const p=document.createElement("span");p.className="stat-trend up",p.appendChild(i()),p.append(` +${e.points_this_week} THIS WEEK`),r.appendChild(p),r.style.color=""}else if(e.points_this_week<0){const p=document.createElement("span");p.className="stat-trend down",p.appendChild(n()),p.append(` ${e.points_this_week} THIS WEEK`),r.appendChild(p),r.style.color=""}}}const c=document.getElementById(`${t}-matches-sub`);if(c&&e.matches_played>0){const o=e.comp_played??0,p=e.friendly_played??0;c.innerHTML=safeHTML(`<span style="color:var(--c-orange);"><span style="font-size:14px; vertical-align:-1px; margin-right:5px;">\u{1F3C6}</span><span style="font-size:14px;">${o}</span></span> <span style="opacity:0.5; margin:0 5px;">|</span> <span style="color:#5B8BFF;"><span style="font-size:17px; vertical-align:-2px; margin-right:5px;">\u{1F91D}</span><span style="font-size:14px;">${p}</span></span>`),c.style.fontSize="12px",c.style.fontWeight="500",c.style.letterSpacing="0.5px"}const f=document.getElementById(`${t}-wl`);f&&e.matches_played>0&&(f.innerHTML=safeHTML(`<span style="color:#4ebd79;">${e.matches_won}W</span> <span style="opacity:0.5; margin:0 5px;">/</span> <span style="color:#e57373;">${e.matches_lost}L</span>`),f.style.fontSize="12px",f.style.fontWeight="500",f.style.letterSpacing="0.5px")}};document.addEventListener("DOMContentLoaded",()=>{if(window.Capacitor?.getPlatform?.()==="ios"||/iPad|iPhone|iPod/.test(navigator.userAgent)&&!window.MSStream||navigator.platform==="MacIntel"&&navigator.maxTouchPoints>1){let n=0,s=0,a=!1;document.addEventListener("touchstart",r=>{if(!r.touches||r.touches.length!==1)return;const c=r.touches[0];c.clientX<=25?(n=c.clientX,s=c.clientY,a=!0):a=!1},{passive:!0}),document.addEventListener("touchend",r=>{if(!a||!r.changedTouches||r.changedTouches.length!==1)return;const c=r.changedTouches[0],f=c.clientX-n,o=Math.abs(c.clientY-s);f>70&&o<50&&f>o*1.5&&(a=!1,typeof Router<"u"&&Router.back&&Router.back()),a=!1},{passive:!0})}Auth.init().then(()=>Auth.syncWithServer()).then(()=>{Router.init(),NotificationsController.init(),SoundManager.init(),typeof Auth<"u"&&Auth.isAuthenticated()&&(PushNotificationsController.init(),InAppMessagesController.init(),typeof UI<"u"&&UI.syncNav&&UI.syncNav())});const t=window.Capacitor?.Plugins?.StatusBar;t&&(t.setBackgroundColor({color:"#0D1117"}),t.setStyle({style:"DARK"}));const i=window.Capacitor?.Plugins?.App;if(i&&(i.addListener("appStateChange",({isActive:n})=>{!n&&typeof ChatController<"u"&&ChatController._isShowing&&ChatController._matchId?ChatController.stop():n&&typeof ChatController<"u"&&ChatController._isShowing&&ChatController._matchId&&setTimeout(()=>{navigator.onLine&&(ChatController.startPoll(),ChatController.loadMessages(!1))},300)}),i.addListener("appUrlOpen",n=>{if(console.log("[App] Deep link received:",n.url),n.url)try{const s=new URL(n.url),a=s.pathname,r=s.search;if(a&&(a.startsWith("/matches/")||a.startsWith("/share/"))){const c=a.replace("/matches/","").replace("/share/","").trim();c&&(console.log("[App] Routing to deep linked match:",c),typeof Router<"u"&&Router.navigate("/matches/"+c,!0,!0))}else a==="/reset-password"?(console.log("[App] Routing to reset-password with token:",r),typeof Router<"u"&&Router.navigate("/reset-password"+r,!0,!0)):a==="/verify-email"&&(console.log("[App] Routing to verify-email with token:",r),typeof Router<"u"&&Router.navigate("/verify-email"+r,!0,!0))}catch(s){console.error("[App] Deep link routing error:",s)}}),i.addListener("backButton",()=>{if(window.location.pathname.replace(CONFIG.BASE_PATH,"")==="/login"){typeof Router<"u"&&Router.back();return}if(typeof ConfirmModal<"u"&&ConfirmModal._isOpen){ConfirmModal.close(!1);return}if(document.getElementById("scoring-modal-overlay")&&typeof ScoringController<"u"){ScoringController.closeModal();return}if(typeof InviteModal<"u"&&InviteModal._isOpen){InviteModal.close();return}if(typeof StoriesController<"u"&&StoriesController._isShowing){StoriesController.closePlayer();return}if(typeof NotificationsController<"u"&&NotificationsController._isOpen){NotificationsController.close();return}Router.navDepth>0?Router.back():i.exitApp()})),window.Capacitor){document.body.classList.add("is-mobile-app");const n=window.Capacitor?.getPlatform?.()||"web";n&&document.body.classList.add(`platform-${n}`);const s=document.createElement("style");if(s.textContent=`
            *::-webkit-scrollbar { display: none !important; width: 0 !important; height: 0 !important; background: transparent !important; }
            *::-webkit-scrollbar-thumb { display: none !important; background: transparent !important; }
            *::-webkit-scrollbar-track { display: none !important; background: transparent !important; }
            html, body { scrollbar-width: none !important; -ms-overflow-style: none !important; }
        `,document.head.appendChild(s),window.Capacitor&&window.Capacitor.Plugins&&window.Capacitor.Plugins.CapacitorUpdater){const a=window.Capacitor.Plugins.CapacitorUpdater;a.notifyAppReady().catch(function(r){}),a.addListener("downloadComplete",function(r){r&&r.bundle&&r.bundle.id?a.set({id:r.bundle.id}).then(function(){return a.reload()}).catch(function(c){return a.reload()}):a.reload().catch(function(c){})}).catch(function(r){}),a.sync().catch(function(r){})}}}),window.togglePasswordVisibility=function(e){if(!e)return;const t=Date.now();if(e._lastToggle&&t-e._lastToggle<300)return;e._lastToggle=t;const i=e.closest(".password-wrap");if(!i)return;const n=i.querySelector("input");if(!n)return;const s=n.type==="password"||n.getAttribute("type")==="password",a=s?"text":"password";n.type=a,n.setAttribute("type",a);const r=e.querySelector("svg"),c=r&&r.getAttribute("width")||"20",f=r&&r.getAttribute("height")||"20";s?e.innerHTML=`
            <svg viewBox="0 0 24 24" width="${c}" height="${f}" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="eye-icon">
                <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path>
                <line x1="1" y1="1" x2="23" y2="23"></line>
            </svg>
        `:e.innerHTML=`
            <svg viewBox="0 0 24 24" width="${c}" height="${f}" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="eye-icon">
                <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                <circle cx="12" cy="12" r="3"></circle>
            </svg>
        `};const handleGlobalMobileAuthToggle=e=>{if(e.target.closest(".show-login-form-btn")){if(e.preventDefault(),e.stopPropagation(),typeof Router<"u")Router.navigate("/login");else{const n=document.querySelector(".auth-page");n&&n.classList.add("mobile-show-form")}return!1}if(e.target.closest(".mobile-back-hero-btn")){if(e.preventDefault(),e.stopPropagation(),typeof Router<"u")Router.back();else{const n=document.querySelector(".auth-page");n&&n.classList.remove("mobile-show-form")}return!1}},handleGlobalPasswordToggle=e=>{const t=e.target.closest(".password-toggle");t&&(e.preventDefault(),window.togglePasswordVisibility(t))};document.addEventListener("pointerdown",handleGlobalPasswordToggle),document.addEventListener("click",handleGlobalPasswordToggle),document.addEventListener("click",handleGlobalMobileAuthToggle,!0);
