var FX={ignite:function(e){e&&(e.classList.remove("ignite"),e.offsetWidth,e.classList.add("ignite"),setTimeout(()=>{e.classList.remove("ignite")},650))}},SoundManager={_ctx:null,_buffers:{},_unlocked:!1,_initialized:!1,init:function(){if(this._initialized)return;this._initialized=!0;const e=()=>{if(this._unlocked)return;const t=window.AudioContext||window.webkitAudioContext;if(t){this._ctx=new t;const i={tap:"assets/sounds/tap.mp3",success:"assets/sounds/success.mp3",notify:"assets/sounds/notify.mp3"};for(const[n,r]of Object.entries(i))fetch(r).then(a=>a.arrayBuffer()).then(a=>this._ctx.decodeAudioData(a)).then(a=>{this._buffers[n]=a}).catch(a=>console.warn("[SoundManager] Load failed:",r,a));this._ctx.state==="suspended"&&this._ctx.resume();const o=this._ctx.createBufferSource();o.buffer=this._ctx.createBuffer(1,1,22050),o.connect(this._ctx.destination),o.start(0)}this._unlocked=!0,["touchstart","click","mousedown"].forEach(i=>document.removeEventListener(i,e))};["touchstart","click","mousedown"].forEach(t=>document.addEventListener(t,e,{passive:!0})),document.addEventListener("click",t=>{const i=t.target.closest("button, a, .nav-item, [onclick], .clickable");i&&!i.hasAttribute("data-no-sound")&&this.play("tap");const o=t.target.closest(".stat-box");o&&(o.classList.remove("clicked"),o.offsetWidth,o.classList.add("clicked"),setTimeout(()=>o.classList.remove("clicked"),600))},!0)},play:function(e){if(!this._ctx||!this._buffers[e])return;this._ctx.state==="suspended"&&this._ctx.resume();const t=this._ctx.createBufferSource();t.buffer=this._buffers[e],t.connect(this._ctx.destination),t.start(0);const i=window.Capacitor?.Plugins?.Haptics;i&&(e==="tap"?i.selectionChanged().catch(()=>{}):e==="success"&&i.notification({type:"SUCCESS"}).catch(()=>{}))}},Toast={show:function(e,t="info",i=5e3){let o=document.getElementById("toast-container");o||(o=document.createElement("div"),o.id="toast-container",document.body.appendChild(o));const n=document.createElement("div");n.className=`toast ${t}`;let r="\u{1F514}";t==="success"&&(r="\u2705"),t==="error"&&(r="\u26A0\uFE0F"),t==="warning"&&(r="\u26A0\uFE0F"),n.innerHTML=safeHTML(`
            <span class="toast-icon">${r}</span>
            <span class="toast-message">${e}</span>
            <button class="toast-close" onclick="this.parentElement.remove()">\u2715</button>
        `),o.appendChild(n),i>0&&setTimeout(()=>{n.parentElement&&(n.style.opacity="0",n.style.transform="translateY(-20px)",setTimeout(()=>{n.parentElement&&n.remove()},300))},i)}},ConfirmModal={_modal:null,_resolve:null,_isOpen:!1,show:function({title:e,message:t,confirmText:i="Confirm",cancelText:o="Cancel",showCancel:n=!0,thirdText:r=null,thirdColor:a="var(--c-secondary)",type:p="info",showInput:h=!1,inputType:u="textarea",required:v=!1,inputPlaceholder:s="Enter reason...",inputMaxLength:d=300,tipText:C="",icon:P=null,undismissable:B=!1,closeOnOverlayClick:T=!0,headerLayout:N="column",playersList:w=null}){return new Promise(O=>{this._resolve=O,this._undismissable=B,this._closeOnOverlayClick=T,this._modal||(this._modal=document.createElement("div"),this._modal.id="global-confirm-modal",this._modal.style.cssText=`
                    position:fixed; top:0; left:0; width:100%; height:100%;
                    background:rgba(0,0,0,0.8);
                    display:flex; flex-direction:column; align-items:center; justify-content:flex-start;
                    z-index:100000; opacity:0; pointer-events:none;
                    transition:opacity 0.25s ease; padding:32px 16px;
                    overflow-y:auto;
                `,document.body.appendChild(this._modal));const l=p==="warning",c=P??(l?"\u26A1":""),g=l?"var(--c-red)":"var(--c-primary)";let y="";if(h)if(u==="radio"){let f='<option value="" disabled selected hidden>Select Player</option>';w&&Array.isArray(w)&&w.forEach(m=>{f+=`<option value="${m.id}">${m.name}</option>`}),y=`
                        <div id="gcm-radio-container" style="margin-bottom:4px; width:100%; display:flex; flex-direction:column; align-items:flex-start;">
                            <label style="display:flex; align-items:center; gap:10px; margin-bottom:12px; cursor:pointer; color:#fff; font-size:14px; font-weight:600; text-align:left; width:100%;">
                                <input type="radio" name="gcm-radio-opt" value="No show" style="accent-color:var(--c-primary); width:18px; height:18px; cursor:pointer;" />
                                <span>No show</span>
                            </label>
                            
                            <label style="display:flex; align-items:center; gap:10px; margin-bottom:12px; cursor:pointer; color:#fff; font-size:14px; font-weight:600; text-align:left; width:100%;">
                                <input type="radio" name="gcm-radio-opt" value="Level mismatch" style="accent-color:var(--c-primary); width:18px; height:18px; cursor:pointer;" />
                                <span>Level mismatch</span>
                            </label>
                            
                            <label style="display:flex; align-items:center; gap:10px; margin-bottom:12px; cursor:pointer; color:#fff; font-size:14px; font-weight:600; text-align:left; width:100%;">
                                <input type="radio" name="gcm-radio-opt" value="Bad attitude" style="accent-color:var(--c-primary); width:18px; height:18px; cursor:pointer;" />
                                <span>Bad attitude</span>
                            </label>

                            ${w&&Array.isArray(w)?`
                            <div id="gcm-radio-player-wrap" style="display:none; margin-bottom:8px; width:100%; padding-left:28px; box-sizing:border-box;">
                                <label style="color:rgba(255,255,255,0.6); display:block; text-align:left; font-size:11px; font-weight:800; text-transform:uppercase; margin-bottom:6px; font-family:var(--font);">Select Player</label>
                                <select id="gcm-player-select" style="width:100%; border:1px solid rgba(255,255,255,0.15); background:rgba(23, 23, 28, 0.98) url(&quot;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='%238B9BB4' stroke-width='2'%3E%3Cpath d='M6 9l6 6 6-6'/%3E%3C/svg%3E&quot;) no-repeat right 16px center; appearance:none; -webkit-appearance:none; color:#fff; border-radius:12px; padding:14px 44px 14px 16px; font-size:14px; font-family:var(--font); outline:none; cursor:pointer;">
                                    ${f}
                                </select>
                            </div>
                            `:""}

                            <label style="display:flex; align-items:center; gap:10px; margin-bottom:12px; cursor:pointer; color:#fff; font-size:14px; font-weight:600; text-align:left; width:100%;">
                                <input type="radio" name="gcm-radio-opt" value="other" style="accent-color:var(--c-primary); width:18px; height:18px; cursor:pointer;" />
                                <span>Other</span>
                            </label>

                            <div id="gcm-radio-other-wrap" style="display:none; margin-bottom:8px; width:100%; padding-left:28px; box-sizing:border-box;">
                                <textarea id="gcm-input" placeholder="Please describe the issue..." maxlength="${d}" style="width:100%; border:1px solid rgba(255,255,255,0.15); background:rgba(255,255,255,0.06); color:#fff; border-radius:12px; padding:12px; font-size:14px; resize:none; font-family:var(--font); outline:none; margin-bottom:4px;" rows="3"></textarea>
                                <div style="display:flex; justify-content:space-between; margin-bottom:0; padding:0 4px;">
                                    <span id="gcm-tip" style="font-size:11px; color:var(--c-text-dim); text-align:left; flex:1; padding-right:10px;">${C}</span>
                                    <span id="gcm-counter" style="font-size:11px; color:var(--c-text-muted); font-weight:700; white-space:nowrap;">0/${d}</span>
                                </div>
                            </div>
                        </div>
                    `}else y=`
                        <${u==="textarea"?"textarea":"input"} id="gcm-input" type="${u}" placeholder="${s}" maxlength="${d}" style="width:100%; border:1px solid rgba(255,255,255,0.15); background:rgba(255,255,255,0.06); color:#fff; border-radius:12px; padding:12px; font-size:14px; margin-bottom:${u==="password"?"18px":"4px"}; resize:none; font-family:var(--font); outline:none;" ${u==="textarea"?'rows="6"':""}></${u==="textarea"?"textarea":"input"}>
                    `;h&&u!=="radio"&&(y+=`
                    <div style="display:${u==="password"?"none":"flex"}; justify-content:space-between; margin-bottom:24px; padding:0 4px;">
                        <span id="gcm-tip" style="font-size:11px; color:var(--c-text-dim); text-align:left; flex:1; padding-right:10px;">${C}</span>
                        <span id="gcm-counter" style="font-size:11px; color:var(--c-text-muted); font-weight:700; white-space:nowrap;">0/${d}</span>
                    </div>
                `);const I=r?`
                <button id="gcm-third" class="btn" style="background:${a}; color:white; border:none; padding:16px;">${r}</button>
            `:"",L=n?`
                <button id="gcm-cancel" class="btn" style="background:none; border:none; color:var(--c-text-muted); padding:12px; font-size:14px; font-weight:600;">${o}</button>
            `:"";let A="";if(N==="row")A=`
                    <div style="display:flex; align-items:flex-end; justify-content:flex-start; gap:10px; margin-bottom:16px; padding-bottom:16px; border-bottom:1px solid rgba(255,255,255,0.08);">
                        ${c?`<div style="font-size:24px; line-height:1;">${c}</div>`:""}
                        <h2 style="font-size:15px; font-weight:800; color:#fff; margin:0; text-transform:uppercase; letter-spacing:0.5px; line-height:1; padding-bottom:2px; text-align:left;">${e}</h2>
                    </div>
                `;else{let f="";c&&(f=`
                    <!-- Premium Emoji Frame -->
                    <div style="margin: 0 auto 20px; width:72px; height:72px; position:relative; display:flex; align-items:center; justify-content:center;">
                        <div style="position:absolute; inset:0; border-radius:50%; background:linear-gradient(135deg, var(--c-primary), #6366f1); opacity:0.15; filter:blur(10px);"></div>
                        <div style="position:absolute; inset:0; border-radius:50%; border:1px solid rgba(255,255,255,0.1); background:rgba(255,255,255,0.03);"></div>
                        <div style="font-size:34px; z-index:1; filter: drop-shadow(0 4px 10px rgba(0,0,0,0.3));">${c}</div>
                    </div>`),A=`
                    ${f}
                    <h2 style="font-size:22px; font-weight:700; background: linear-gradient(135deg, #ffffff 0%, #a5b4fc 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; margin-bottom:20px; letter-spacing:-0.5px; line-height:1.2; text-align:${c?"center":"left"};">${e}</h2>
                `}const x=N==="row",E=x?"380px":"340px",$=x?"20px":"28px",z=x?"24px":"32px";if(this._modal.innerHTML=safeHTML(`
                <div id="gcm-card" style="margin: auto 0; flex-shrink: 0; background:rgba(23, 23, 28, 0.98); backdrop-filter:blur(8px); border:1px solid rgba(255,255,255,0.1); border-radius:${z}; padding:${$}; width:100%; max-width:${E}; text-align:center; position:relative; transform:scale(0.85); opacity:0; transition:all 0.4s cubic-bezier(0.16, 1, 0.3, 1); box-shadow:0 30px 60px rgba(0,0,0,0.6);">
                    
                    ${A}
                    
                    ${y}
 
                    ${t?`<div style="font-size:12px; color:rgba(255,255,255,0.5); line-height:1.6; margin-bottom:24px; font-weight:400; text-align:left; padding:0;">${t.replace(/\n/g,"<br>")}</div>`:""}
 
                    <div style="display:flex; gap:12px; flex-direction:column;">
                        <button id="gcm-confirm" class="btn" style="background:var(--c-primary); color:#fff; border:none; width:100%; padding:14px; border-radius:16px; font-weight:800; font-size:14px; letter-spacing:0.5px; box-shadow: 0 8px 20px rgba(27, 82, 206, 0.25); transition:transform 0.2s;">
                            ${i.toUpperCase()}
                        </button>
                        ${I}
                        ${L}
                    </div>
                </div>
            `),this._modal.onclick=f=>{f.target===this._modal&&!this._undismissable&&this._closeOnOverlayClick&&this.close(!1)},this._modal.querySelector("#gcm-confirm").onclick=()=>{let f=null;if(h)if(u==="radio"){const m=this._modal.querySelector('input[name="gcm-radio-opt"]:checked');if(!m){Toast.show("Please select an option.","error");return}const k=m.value;if(k==="other"){const b=this._modal.querySelector("#gcm-input").value.trim();if(b===""){this._modal.querySelector("#gcm-input").style.borderColor="var(--c-red)",Toast.show("Please describe the issue.","error");return}f="Other: "+b}else{if(w&&Array.isArray(w)){const b=this._modal.querySelector("#gcm-player-select");if(!b||b.value===""){Toast.show("Please select a player.","error");return}}f=k}}else{const m=this._modal.querySelector("#gcm-input").value.trim();if(v&&m===""){const k=this._modal.querySelector("#gcm-input");k.style.borderColor="var(--c-red)";const b=u==="password"?"Please enter your password.":"Please enter a message.";Toast.show(b,"error");return}f=m}else f=!0;if(w&&Array.isArray(w)){const m=this._modal.querySelector('input[name="gcm-radio-opt"]:checked'),k=m&&m.value==="other",b=this._modal.querySelector("#gcm-player-select"),S=!k&&b?parseInt(b.value):null;this.close({reason:f,targetUserId:S})}else this.close(f)},h){const f=this._modal.querySelector("#gcm-input"),m=this._modal.querySelector("#gcm-counter");if(u==="radio"){const k=this._modal.querySelectorAll('input[name="gcm-radio-opt"]'),b=this._modal.querySelector("#gcm-radio-other-wrap"),S=this._modal.querySelector("#gcm-radio-player-wrap");k.forEach(R=>{R.onchange=()=>{const H=R.closest("label");R.value==="other"?(b.style.display="block",S&&(S.style.display="none"),setTimeout(()=>f.focus(),100)):(b.style.display="none",S&&(S.style.display="block",H.parentNode.insertBefore(S,H.nextSibling)))}})}f.oninput=()=>{m&&(m.innerText=`${f.value.length}/${d}`),f.style.borderColor="var(--c-border)"},u!=="radio"&&setTimeout(()=>f.focus(),300)}r&&(this._modal.querySelector("#gcm-third").onclick=()=>this.close("third"));const _=this._modal.querySelector("#gcm-cancel");_&&(_.onclick=()=>this.close(!1));const M=window.scrollY||document.documentElement.scrollTop;document.documentElement.style.overflow="hidden",document.body.style.overflow="hidden",document.body.style.position="fixed",document.body.style.top=`-${M}px`,document.body.style.width="100%",this._isOpen=!0,this._modal.style.opacity="1",this._modal.style.pointerEvents="auto",setTimeout(()=>{const f=document.getElementById("gcm-card");f&&(f.style.transform="scale(1)",f.style.opacity="1")},10)})},close:function(e){if(!this._modal)return;if(this._undismissable){if(this._resolve){const o=this._resolve;this._resolve=null,o(e)}return}const t=parseFloat(document.body.style.top||"0")*-1;document.documentElement.style.overflow="",document.body.style.overflow="",document.body.style.touchAction="",document.body.style.position="",document.body.style.top="",document.body.style.width="",this._modal.ontouchmove=null,t>0&&window.scrollTo(0,t),this._isOpen=!1,this._modal.style.opacity="0",this._modal.style.pointerEvents="none";const i=document.getElementById("gcm-card");i&&(i.style.transform="scale(0.95)",i.style.opacity="0"),setTimeout(()=>{this._resolve&&this._resolve(e)},250)}},InviteModal={_modal:null,_isOpen:!1,show:function(e,t){this._modal||(this._modal=document.createElement("div"),this._modal.id="invite-modal-overlay",this._modal.style.cssText=`
                position:fixed; top:0; left:0; width:100%; height:100%;
                background:rgba(0,0,0,0.8);
                display:flex; flex-direction:column; align-items:center; justify-content:flex-start;
                z-index:100000; opacity:0; pointer-events:none;
                transition:opacity 0.25s ease; padding:32px 16px;
                overflow-y:auto;
            `,document.body.appendChild(this._modal));const i=e.map((n,r)=>{const a=!!n.used_at;let p="";if(a){let h="?";n.used_by_name&&(h=n.used_by_name.substring(0,2).toUpperCase()),p=`
                    <div style="display:flex; align-items:center; gap:10px; width:100%;">
                        ${UI.getAvatarHtml(n.used_by_avatar,"width:100%; height:100%; border-radius:50%; object-fit:cover;","width:32px; height:32px; border-radius:50%; flex-shrink:0; font-size:11px; font-weight:700; display:flex; align-items:center; justify-content:center; background:rgba(255,255,255,0.06); color:#fff;",h)}
                        <div style="flex:1; text-align:left; min-width:0;">
                            <div style="font-weight:700; font-size:13px; color:#fff; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">Used by ${n.used_by_name}</div>
                            <div style="font-size:10px; color:var(--c-orange); font-weight:800; font-family:monospace; margin-top:2px;">CODE: ${n.code}</div>
                        </div>
                        <span style="font-size:18px; color:var(--c-green); flex-shrink:0;">\u2713</span>
                    </div>
                `}else p=`
                    <div style="display:flex; align-items:center; justify-content:space-between; width:100%;">
                        <span style="font-family: 'JetBrains Mono', monospace; font-size:15px; font-weight:800; color:#fff; letter-spacing:0.5px;">${n.code}</span>
                        <button onclick="InviteModal.copyCode('${n.code}', this)" class="btn btn-sm" style="background:rgba(255,255,255,0.05); color:#fff; border:1px solid rgba(255,255,255,0.1); padding:6px 14px; border-radius:8px; font-size:11px; font-weight:700; transition:all 0.2s; cursor:pointer;" onmouseover="this.style.background='rgba(255,255,255,0.1)'" onmouseout="this.style.background='rgba(255,255,255,0.05)'">
                            COPY
                        </button>
                    </div>
                `;return`
                <div style="display:flex; align-items:center; background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); border-radius:16px; padding:14px 18px; margin-bottom:12px; transition:all 0.2s;">
                    ${p}
                </div>
            `}).join("");this._modal.innerHTML=safeHTML(`
             <div id="invite-modal-card" style="margin: auto 0; background:rgba(23, 23, 28, 0.98); backdrop-filter:blur(8px); border:1px solid rgba(255,255,255,0.1); border-radius:32px; padding:28px; width:100%; max-width:340px; text-align:center; position:relative; transform:scale(0.85); opacity:0; transition:all 0.4s cubic-bezier(0.16, 1, 0.3, 1); box-shadow:0 30px 60px rgba(0,0,0,0.6);">
                <div style="margin: 0 auto 20px; width:72px; height:72px; position:relative; display:flex; align-items:center; justify-content:center;">
                    <div style="position:absolute; inset:0; border-radius:50%; background:linear-gradient(135deg, var(--c-orange), #ff8b00); opacity:0.15; filter:blur(10px);"></div>
                    <div style="position:absolute; inset:0; border-radius:50%; border:1px solid rgba(255,255,255,0.1); background:rgba(255,255,255,0.03);"></div>
                    <div style="font-size:34px; z-index:1; filter: drop-shadow(0 4px 10px rgba(0,0,0,0.3));">\u{1F39F}\uFE0F</div>
                </div>
                <h2 style="font-size:20px; font-weight:900; color:#fff; margin-bottom:8px; letter-spacing:-0.5px; line-height:1.2;">Exclusive Invites</h2>
                <p style="font-size:12px; color:var(--c-text-muted); line-height:1.6; margin-bottom:24px; font-weight:400; padding:0 8px; text-align:center;">
                    Your friends need one of these exclusive codes to register. Give them out wisely!
                </p>

                <div style="margin-bottom:24px;">
                    ${i}
                </div>

                <div>
                    <button onclick="InviteModal.close()" class="btn" style="background:var(--c-primary); color:#fff; border:none; width:100%; padding:14px; border-radius:16px; font-weight:800; font-size:14px; letter-spacing:0.5px; box-shadow: 0 8px 20px rgba(27, 82, 206, 0.25); transition:transform 0.2s;">
                        CLOSE
                    </button>
                </div>
            </div>
        `),this._modal.onclick=n=>{n.target===this._modal&&this.close()};const o=window.scrollY||document.documentElement.scrollTop;document.documentElement.style.overflow="hidden",document.body.style.overflow="hidden",document.body.style.position="fixed",document.body.style.top=`-${o}px`,document.body.style.width="100%",this._isOpen=!0,this._modal.style.opacity="1",this._modal.style.pointerEvents="auto",setTimeout(()=>{const n=document.getElementById("invite-modal-card");n&&(n.style.transform="scale(1)",n.style.opacity="1")},10)},copyCode:function(e,t){if(!navigator.clipboard){const i=document.createElement("textarea");i.value=e,i.style.position="fixed",document.body.appendChild(i),i.focus(),i.select();try{document.execCommand("copy"),this.onCopySuccess(t)}catch(o){console.error("Fallback copy failed",o)}document.body.removeChild(i);return}navigator.clipboard.writeText(e).then(()=>{this.onCopySuccess(t)}).catch(i=>{console.error("Clipboard copy failed",i)})},onCopySuccess:function(e){if(e){const t=e.textContent;e.textContent="COPIED!",e.style.borderColor="var(--c-green)",e.style.color="var(--c-green)",e.style.background="rgba(16,185,129,0.1)",setTimeout(()=>{e.textContent=t,e.style.borderColor="rgba(255,255,255,0.1)",e.style.color="#fff",e.style.background="rgba(255,255,255,0.05)"},2e3)}Toast.show("Invitation code copied to clipboard!","success")},close:function(){if(!this._modal)return;const e=parseFloat(document.body.style.top||"0")*-1;document.documentElement.style.overflow="",document.body.style.overflow="",document.body.style.touchAction="",document.body.style.position="",document.body.style.top="",document.body.style.width="",e>0&&window.scrollTo(0,e),this._isOpen=!1,this._modal.style.opacity="0",this._modal.style.pointerEvents="none";const t=document.getElementById("invite-modal-card");t&&(t.style.transform="scale(0.95)",t.style.opacity="0")}},PollManager={_timer:null,_activeTask:null,start:function(e,t,i=15e3){this.stop(),this._activeTask=e,this._timer=setInterval(()=>{console.log(`[PollManager] Running: ${e}`),t()},i)},stop:function(){this._timer&&(console.log(`[PollManager] Stopping: ${this._activeTask}`),clearInterval(this._timer),this._timer=null,this._activeTask=null)}},PushNotificationsController={_isStartingUp:!0,init:async function(){const e=window.Capacitor?.Plugins?.PushNotifications;if(!e){console.log("[PushNotifications] Not a native app or plugin missing");return}setTimeout(()=>{this._isStartingUp=!1,console.log("[PushNotifications] Startup silence period ended")},3e3),await new Promise(t=>setTimeout(t,2e3));try{console.log("[PushNotifications] Starting registration flow...");let t=await e.checkPermissions();if(console.log("[PushNotifications] Permission status:",t.receive),t.receive==="prompt"&&(t=await e.requestPermissions()),t.receive!=="granted"){console.log("[PushNotifications] Permission not granted");return}console.log("[PushNotifications] Registering..."),await e.register(),this.setupListeners(e)}catch(t){console.error("[PushNotifications] Initialization crash prevented:",t)}},setupListeners:function(e){if(e)try{e.addListener("registration",t=>{console.log("[PushNotifications] Registration success"),this.updateServerToken(t.value)}),e.addListener("registrationError",t=>{console.error("[PushNotifications] Registration error:",t.error)}),e.addListener("pushNotificationReceived",t=>{console.log("[PushNotifications] Received in foreground:",t),t.title&&t.body&&(Toast.show(t.body,"info"),typeof SoundManager<"u"&&!this._isStartingUp&&SoundManager.play("notify"),typeof Router<"u"&&Router.currentPath==="/dashboard"&&typeof DashboardController<"u"&&DashboardController.load())}),e.addListener("pushNotificationActionPerformed",t=>{console.log("[PushNotifications] Action performed. App opened via notification.")})}catch(t){console.error("[PushNotifications] Listener setup failed:",t)}},updateServerToken:async function(e){if(typeof Auth<"u"&&!Auth.isAuthenticated())return;const t=window.Capacitor?.getPlatform?.()||"web";console.log("[PushNotifications] Updating server token..."),await API.post("/profile/update_device_token",{token:e,platform:t})}};const InAppMessagesController={init:async function(){Auth.isAuthenticated()&&this.check()},check:async function(){try{const e=await API.get("/system/check_in_app_messages?t="+Date.now());e.success&&e.data&&this.display(e.data)}catch(e){console.error("[InAppMessages] Check failed:",e)}},display:async function(e){let t=e.button_text||"Got it",i=e.action_type;ConfirmModal.show({title:e.heading,message:e.body,icon:e.emoji,confirmText:t,showCancel:!1,type:"info",undismissable:e.is_undismissable==1,closeOnOverlayClick:!1}).then(async o=>{if(await API.post("/system/mark_message_seen",{message_id:e.id}),!!o){if(i==="navigate"&&e.page_route)Router.navigate(e.page_route);else if(i==="external"){const n=window.Capacitor?.getPlatform?.()||"web";let r=e.android_url;n==="ios"&&(r=e.ios_url||e.android_url),r&&window.open(r,"_blank")}}})}},ScoreUI={renderMatchScore:function(e,t=null,i=null,o=!0,n=null){if(!t&&e.scores&&(t=e.scores.find(l=>l.status==="approved")),!t)return"";const r=[];let a=0,p=0;for(let l=1;l<=3;l++){const c=parseInt(t[`t1_set${l}`]),g=parseInt(t[`t2_set${l}`]);if(isNaN(c)||isNaN(g)||l>1&&c===0&&g===0)continue;const y=c>g?1:g>c?2:0;y===1?a++:y===2&&p++,r.push({s1:c,s2:g,winner:y})}const h=a>p;let u=[],v=[];const s=i||[...e.team_a||[],...e.team_b||[]];let d=null;if(t.composition_json)try{d=typeof t.composition_json=="string"?JSON.parse(t.composition_json):t.composition_json}catch{}d&&d.length>0?d.forEach(l=>{const c=s.find(y=>parseInt(y.user_id||y.id)===parseInt(l.user_id)),g={name:l.nickname||l.name||(c?c.nickname||c.name||c.first_name+" "+c.last_name:"\u2014"),code:l.player_code||l.code||(c?c.player_code||c.code:""),team_no:parseInt(l.team_no),user_id:parseInt(l.user_id),point_change:c?.point_change??null};g.team_no===1?u.push(g):g.team_no===2&&v.push(g)}):s.forEach(l=>{const c={name:l.nickname||l.name||l.first_name+" "+l.last_name||"\u2014",code:l.player_code||l.code||"",team_no:parseInt(l.team_no),user_id:parseInt(l.user_id||l.id),point_change:l.point_change??null};c.team_no===1?u.push(c):c.team_no===2&&v.push(c)});const C=(l,c)=>{const g=l[0]||{name:"\u2014"},y=l[1]||{name:"\u2014"},I=e.match_type==="friendly",L=I?"#5A91FF":"var(--c-orange)",A=x=>{let E="";const $=t?.point_changes?.[x.user_id]??t?.point_changes?.[String(x.user_id)],z=$??x.point_change;if(n&&parseInt(x.user_id)===parseInt(n)&&z!==null&&z!==void 0){const _=parseInt(z);if(_!==0&&!isNaN(_)){const M=_>0?"#064e3b":"#450a0a",f=_>0?"#4ade80":"#f87171",m=_>0?"1px solid rgba(74,222,128,0.4)":"1px solid rgba(248,113,113,0.4)",k=_>0?"\u2191":"\u2193";E=`<span style="font-size:10px; font-weight:700; letter-spacing:0.3px; background:${M}; color:${f}; padding:0 6px; border-radius:10px; border:${m}; box-shadow:0 2px 6px rgba(0,0,0,0.4); white-space:nowrap; display:inline-flex; align-items:center; height:18px; line-height:1; margin-left:3px; vertical-align:middle;"><span style="font-size:11px; margin-right:2px; font-weight:800;">${k}</span>${Math.abs(_)}</span>`}}return`<span class="msc-premium-player-name">${x.name}</span>${E}`};return`
                <div class="msc-premium-row" style="opacity:${c?"1":"0.85"}; background:${c?I?"rgba(90,145,255,0.06)":"rgba(247,148,29,0.06)":"transparent"};">
                    <div class="msc-premium-players" style="font-weight:${c?"700":"400"}; color:${c?"#fff":"rgba(255,255,255,0.8)"};">
                        ${A(g)}
                        <span style="opacity:0.25; margin:0 4px;">/</span>
                        ${A(y)}
                    </div>
                    <div class="msc-premium-scores">
                        ${r.map(x=>{const E=x.winner===(l===u?1:2),$=l===u?x.s1:x.s2;return`
                                <span class="msc-premium-score-val" style="color:${E?L:"rgba(255,255,255,0.35)"};">
                                    ${$}
                                </span>
                            `}).join("")}
                    </div>
                </div>
            `},P=(e.venue||"Venue TBD").split(" - ")[0].trim(),B=e.scheduled_at?new Date(e.scheduled_at.replace(" ","T")).toLocaleDateString("en-US",{weekday:"short",day:"numeric",month:"short"}):"",T=e.match_type==="friendly",w=o?`
            <div class="msc-premium-header">
                <span class="msc-premium-venue-date">${P} \u2022 ${B}</span>
                <span class="msc-premium-type-badge" style="color:${T?"#5A91FF":"var(--c-orange)"};">
                    ${T?"\u{1F91D} Friendly":"\u{1F3C6} Competition"}
                </span>
            </div>
        `:"",O=T?"#5A91FF":"var(--c-orange)";return`
            <div class="msc-premium-card">
                ${w}
                <div class="msc-premium-body">
                    ${C(u,h)}
                    ${C(v,!h)}
                </div>
            </div>
        `},renderSkeleton:function(e=3){let t="";for(let i=0;i<e;i++)t+=`
                <div style="margin-bottom:12px; padding:16px; background:rgba(255,255,255,0.02); border-radius:var(--r-lg); border:1px solid rgba(255,255,255,0.05); overflow:hidden;">
                    <div style="display:flex; align-items:center; gap:8px; margin-bottom:16px; padding:0 4px;">
                        <div class="skeleton" style="width:80px; height:10px; border-radius:4px; opacity:0.6;"></div>
                        <div style="width:4px; height:4px; border-radius:50%; background:var(--c-border); opacity:0.3;"></div>
                        <div class="skeleton" style="width:60px; height:10px; border-radius:4px; opacity:0.4;"></div>
                    </div>
                    <div style="display:flex; flex-direction:column; gap:8px;">
                        <div style="display:flex; justify-content:space-between; align-items:center; background:rgba(255,255,255,0.01); padding:10px 12px; border-radius:10px; border:1px solid rgba(255,255,255,0.02);">
                            <div style="display:flex; align-items:center; gap:8px;">
                                <div style="width:10px; height:10px; border-radius:2px; background:var(--c-border); opacity:0.2;"></div>
                                <div style="display:flex; gap:6px;">
                                    <div class="skeleton" style="width:90px; height:12px; border-radius:4px;"></div>
                                    <div class="skeleton" style="width:36px; height:12px; border-radius:4px; opacity:0.5;"></div>
                                </div>
                            </div>
                            <div style="display:flex; gap:10px;">
                                <div class="skeleton" style="width:14px; height:16px; border-radius:4px; opacity:0.8;"></div>
                                <div class="skeleton" style="width:14px; height:16px; border-radius:4px; opacity:0.4;"></div>
                            </div>
                        </div>
                        <div style="display:flex; justify-content:space-between; align-items:center; background:rgba(255,255,255,0.01); padding:10px 12px; border-radius:10px; border:1px solid rgba(255,255,255,0.02);">
                            <div style="display:flex; align-items:center; gap:8px;">
                                <div style="width:10px; height:10px; border-radius:2px; background:transparent;"></div>
                                <div style="display:flex; gap:6px;">
                                    <div class="skeleton" style="width:110px; height:12px; border-radius:4px;"></div>
                                    <div class="skeleton" style="width:36px; height:12px; border-radius:4px; opacity:0.5;"></div>
                                </div>
                            </div>
                            <div style="display:flex; gap:10px;">
                                <div class="skeleton" style="width:14px; height:16px; border-radius:4px; opacity:0.4;"></div>
                                <div class="skeleton" style="width:14px; height:16px; border-radius:4px; opacity:0.8;"></div>
                            </div>
                        </div>
                    </div>
                </div>
            `;return t}},RankingUI={renderSkeleton:function(e=5){let t="";for(let i=0;i<e;i++)t+=`
                <div style="padding:14px 10px; display:grid; grid-template-columns: 40px 1fr 60px; align-items:center; gap:12px; border-bottom:1px solid rgba(255,255,255,0.05); overflow:hidden;">
                    <div style="display:flex; justify-content:center;">
                        <div class="skeleton" style="width:24px; height:24px; border-radius:50%; opacity:0.3;"></div>
                    </div>
                    <div style="display:flex; align-items:center; gap:12px;">
                        <div class="skeleton" style="width:36px; height:36px; border-radius:50%; flex-shrink:0;"></div>
                        <div style="display:flex; flex-direction:column; gap:6px; flex:1;">
                            <div class="skeleton" style="width:120px; height:12px; border-radius:4px;"></div>
                            <div class="skeleton" style="width:80px; height:10px; border-radius:4px; opacity:0.5;"></div>
                        </div>
                    </div>
                    <div style="display:flex; justify-content:flex-end;">
                        <div class="skeleton" style="width:40px; height:14px; border-radius:4px;"></div>
                    </div>
                </div>
            `;return t}},StatsUI={update:function(e,t,i=document){if(!e)return;const o=s=>i&&i.querySelector&&i.querySelector("#"+s)||document.getElementById(s),n=()=>{const s=document.createElementNS("http://www.w3.org/2000/svg","svg");s.setAttribute("width","12"),s.setAttribute("height","12"),s.setAttribute("viewBox","0 0 24 24"),s.setAttribute("fill","none"),s.setAttribute("stroke","currentColor"),s.setAttribute("stroke-width","4"),s.setAttribute("stroke-linecap","round"),s.setAttribute("stroke-linejoin","round");const d=document.createElementNS("http://www.w3.org/2000/svg","polyline");return d.setAttribute("points","18 15 12 9 6 15"),s.appendChild(d),s},r=()=>{const s=document.createElementNS("http://www.w3.org/2000/svg","svg");s.setAttribute("width","12"),s.setAttribute("height","12"),s.setAttribute("viewBox","0 0 24 24"),s.setAttribute("fill","none"),s.setAttribute("stroke","currentColor"),s.setAttribute("stroke-width","4"),s.setAttribute("stroke-linecap","round"),s.setAttribute("stroke-linejoin","round");const d=document.createElementNS("http://www.w3.org/2000/svg","polyline");return d.setAttribute("points","6 9 12 15 18 9"),s.appendChild(d),s},a={ranking:e.ranking??"\u2014",points:e.points,matches:e.matches_played,winrate:e.win_rate+"%"};for(const[s,d]of Object.entries(a)){const C=o(`${t}-${s}`)||o(`${t}-${s}-count`);C&&(C.innerHTML="",C.textContent=d)}const p=o(`${t}-ranking-change`)||o(`${t}-highest-rank`);if(p){p.innerHTML="";const s=document.createElement("span");e.ranking_change>0?(s.className="stat-trend up",s.appendChild(n()),s.append(` ${e.ranking_change} POSITIONS`)):e.ranking_change<0?(s.className="stat-trend down",s.appendChild(r()),s.append(` ${Math.abs(e.ranking_change)} POSITIONS`)):(s.className="stat-trend neutral",s.textContent="STABLE RANK"),p.appendChild(s)}const h=o(`${t}-points-week`);if(h){h.innerHTML="";const s=e.current_buffer??0;if(s>0){const d=document.createElement("span");d.style.cssText="color: var(--c-orange); background: rgba(255, 139, 0, 0.12); border: 1px solid rgba(255, 139, 0, 0.25); padding: 3px 8px; border-radius: 6px; display: inline-flex; align-items: baseline; gap: 6px;",d.innerHTML=`<span style="font-size: 13px; font-weight: 800;">+${s}</span><span style="font-size: 9px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px;">BUFFER</span>`,h.appendChild(d),h.style.color=""}else if(e.points_this_week!==void 0){if(e.points_this_week>0){const d=document.createElement("span");d.className="stat-trend up",d.appendChild(n()),d.append(` +${e.points_this_week} THIS WEEK`),h.appendChild(d),h.style.color=""}else if(e.points_this_week<0){const d=document.createElement("span");d.className="stat-trend down",d.appendChild(r()),d.append(` ${e.points_this_week} THIS WEEK`),h.appendChild(d),h.style.color=""}}}const u=o(`${t}-matches-sub`);if(u&&e.matches_played>0){const s=e.comp_played??0,d=e.friendly_played??0;u.innerHTML=safeHTML(`<span style="color:var(--c-orange);"><span style="font-size:14px; vertical-align:-1px; margin-right:5px;">\u{1F3C6}</span><span style="font-size:14px;">${s}</span></span> <span style="opacity:0.5; margin:0 5px;">|</span> <span style="color:#5B8BFF;"><span style="font-size:17px; vertical-align:-2px; margin-right:5px;">\u{1F91D}</span><span style="font-size:14px;">${d}</span></span>`),u.style.fontSize="12px",u.style.fontWeight="500",u.style.letterSpacing="0.5px"}const v=o(`${t}-wl`);v&&e.matches_played>0&&(v.innerHTML=safeHTML(`<span style="color:#4ebd79;">${e.matches_won}W</span> <span style="opacity:0.5; margin:0 5px;">/</span> <span style="color:#e57373;">${e.matches_lost}L</span>`),v.style.fontSize="12px",v.style.fontWeight="500",v.style.letterSpacing="0.5px")}};document.addEventListener("DOMContentLoaded",()=>{if(window.Capacitor?.getPlatform?.()==="ios"||/iPad|iPhone|iPod/.test(navigator.userAgent)&&!window.MSStream||navigator.platform==="MacIntel"&&navigator.maxTouchPoints>1){let o=0,n=0,r=!1;document.addEventListener("touchstart",a=>{if(!a.touches||a.touches.length!==1)return;const p=a.touches[0];p.clientX<=25?(o=p.clientX,n=p.clientY,r=!0):r=!1},{passive:!0}),document.addEventListener("touchend",a=>{if(!r||!a.changedTouches||a.changedTouches.length!==1)return;const p=a.changedTouches[0],h=p.clientX-o,u=Math.abs(p.clientY-n);h>70&&u<50&&h>u*1.5&&(r=!1,typeof Router<"u"&&Router.back&&Router.back()),r=!1},{passive:!0})}Auth.init().then(()=>Auth.syncWithServer()).then(()=>{Router.init(),NotificationsController.init(),SoundManager.init(),typeof Auth<"u"&&Auth.isAuthenticated()&&(PushNotificationsController.init(),InAppMessagesController.init(),typeof UI<"u"&&UI.syncNav&&UI.syncNav())});const t=window.Capacitor?.Plugins?.StatusBar;t&&(t.setBackgroundColor({color:"#0D1117"}),t.setStyle({style:"DARK"}));const i=window.Capacitor?.Plugins?.App;if(i&&(i.addListener("appStateChange",({isActive:o})=>{!o&&typeof ChatController<"u"&&ChatController._isShowing&&ChatController._matchId?ChatController.stop():o&&typeof ChatController<"u"&&ChatController._isShowing&&ChatController._matchId&&setTimeout(()=>{navigator.onLine&&(ChatController.startPoll(),ChatController.loadMessages(!1))},300)}),i.addListener("appUrlOpen",o=>{if(console.log("[App] Deep link received:",o.url),o.url)try{const n=new URL(o.url),r=n.pathname,a=n.search;if(r&&(r.startsWith("/matches/")||r.startsWith("/share/"))){const p=r.replace("/matches/","").replace("/share/","").trim();p&&(console.log("[App] Routing to deep linked match:",p),typeof Router<"u"&&Router.navigate("/matches/"+p,!0,!0))}else r==="/reset-password"?(console.log("[App] Routing to reset-password with token:",a),typeof Router<"u"&&Router.navigate("/reset-password"+a,!0,!0)):r==="/verify-email"&&(console.log("[App] Routing to verify-email with token:",a),typeof Router<"u"&&Router.navigate("/verify-email"+a,!0,!0))}catch(n){console.error("[App] Deep link routing error:",n)}}),i.addListener("backButton",()=>{if(window.location.pathname.replace(CONFIG.BASE_PATH,"")==="/login"){typeof Router<"u"&&Router.back();return}if(typeof ConfirmModal<"u"&&ConfirmModal._isOpen){ConfirmModal.close(!1);return}if(document.getElementById("scoring-modal-overlay")&&typeof ScoringController<"u"){ScoringController.closeModal();return}if(typeof InviteModal<"u"&&InviteModal._isOpen){InviteModal.close();return}if(typeof StoriesController<"u"&&StoriesController._isShowing){StoriesController.closePlayer();return}if(typeof NotificationsController<"u"&&NotificationsController._isOpen){NotificationsController.close();return}Router.navDepth>0?Router.back():i.exitApp()})),window.Capacitor){document.body.classList.add("is-mobile-app");const o=window.Capacitor?.getPlatform?.()||"web";o&&document.body.classList.add(`platform-${o}`);const n=document.createElement("style");if(n.textContent=`
            *::-webkit-scrollbar { display: none !important; width: 0 !important; height: 0 !important; background: transparent !important; }
            *::-webkit-scrollbar-thumb { display: none !important; background: transparent !important; }
            *::-webkit-scrollbar-track { display: none !important; background: transparent !important; }
            html, body { scrollbar-width: none !important; -ms-overflow-style: none !important; }
        `,document.head.appendChild(n),window.Capacitor&&window.Capacitor.Plugins&&window.Capacitor.Plugins.CapacitorUpdater){const r=window.Capacitor.Plugins.CapacitorUpdater;r.notifyAppReady().catch(function(a){}),r.addListener("downloadComplete",function(a){a&&a.bundle&&a.bundle.id?r.set({id:a.bundle.id}).then(function(){return r.reload()}).catch(function(p){return r.reload()}):r.reload().catch(function(p){})}).catch(function(a){}),r.sync().catch(function(a){})}}}),window.togglePasswordVisibility=function(e){if(!e)return;const t=Date.now();if(e._lastToggle&&t-e._lastToggle<300)return;e._lastToggle=t;const i=e.closest(".password-wrap");if(!i)return;const o=i.querySelector("input");if(!o)return;const n=o.type==="password"||o.getAttribute("type")==="password",r=n?"text":"password";o.type=r,o.setAttribute("type",r);const a=e.querySelector("svg"),p=a&&a.getAttribute("width")||"20",h=a&&a.getAttribute("height")||"20";n?e.innerHTML=`
            <svg viewBox="0 0 24 24" width="${p}" height="${h}" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="eye-icon">
                <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path>
                <line x1="1" y1="1" x2="23" y2="23"></line>
            </svg>
        `:e.innerHTML=`
            <svg viewBox="0 0 24 24" width="${p}" height="${h}" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="eye-icon">
                <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                <circle cx="12" cy="12" r="3"></circle>
            </svg>
        `};const handleGlobalMobileAuthToggle=e=>{if(e.target.closest(".show-login-form-btn")){if(e.preventDefault(),e.stopPropagation(),typeof Router<"u")Router.navigate("/login");else{const o=document.querySelector(".auth-page");o&&o.classList.add("mobile-show-form")}return!1}if(e.target.closest(".mobile-back-hero-btn")){if(e.preventDefault(),e.stopPropagation(),typeof Router<"u")Router.back();else{const o=document.querySelector(".auth-page");o&&o.classList.remove("mobile-show-form")}return!1}},handleGlobalPasswordToggle=e=>{const t=e.target.closest(".password-toggle");t&&(e.preventDefault(),window.togglePasswordVisibility(t))};document.addEventListener("pointerdown",handleGlobalPasswordToggle),document.addEventListener("click",handleGlobalPasswordToggle),document.addEventListener("click",handleGlobalMobileAuthToggle,!0);
