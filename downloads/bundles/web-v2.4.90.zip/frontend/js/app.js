var FX={ignite:function(e){e&&(e.classList.remove("ignite"),e.offsetWidth,e.classList.add("ignite"),setTimeout(()=>{e.classList.remove("ignite")},650))}},SoundManager={_ctx:null,_buffers:{},_unlocked:!1,_initialized:!1,init:function(){if(this._initialized)return;this._initialized=!0;const e=()=>{if(this._unlocked)return;const t=window.AudioContext||window.webkitAudioContext;if(t){this._ctx=new t;const o={tap:"assets/sounds/tap.mp3",success:"assets/sounds/success.mp3",notify:"assets/sounds/notify.mp3"};for(const[n,a]of Object.entries(o))fetch(a).then(d=>d.arrayBuffer()).then(d=>this._ctx.decodeAudioData(d)).then(d=>{this._buffers[n]=d}).catch(d=>console.warn("[SoundManager] Load failed:",a,d));this._ctx.state==="suspended"&&this._ctx.resume();const s=this._ctx.createBufferSource();s.buffer=this._ctx.createBuffer(1,1,22050),s.connect(this._ctx.destination),s.start(0)}this._unlocked=!0,["touchstart","click","mousedown"].forEach(o=>document.removeEventListener(o,e))};["touchstart","click","mousedown"].forEach(t=>document.addEventListener(t,e,{passive:!0})),document.addEventListener("click",t=>{const o=t.target.closest("button, a, .nav-item, [onclick], .clickable");o&&!o.hasAttribute("data-no-sound")&&this.play("tap");const s=t.target.closest(".stat-box");s&&(s.classList.remove("clicked"),s.offsetWidth,s.classList.add("clicked"),setTimeout(()=>s.classList.remove("clicked"),600))},!0)},play:function(e){if(!this._ctx||!this._buffers[e])return;this._ctx.state==="suspended"&&this._ctx.resume();const t=this._ctx.createBufferSource();t.buffer=this._buffers[e],t.connect(this._ctx.destination),t.start(0);const o=window.Capacitor?.Plugins?.Haptics;o&&(e==="tap"?o.selectionChanged().catch(()=>{}):e==="success"&&o.notification({type:"SUCCESS"}).catch(()=>{}))}},Toast={show:function(e,t="info",o=5e3){let s=document.getElementById("toast-container");s||(s=document.createElement("div"),s.id="toast-container",document.body.appendChild(s));const n=document.createElement("div");n.className=`toast ${t}`;let a="\u{1F514}";t==="success"&&(a="\u2705"),t==="error"&&(a="\u26A0\uFE0F"),t==="warning"&&(a="\u26A0\uFE0F"),n.innerHTML=safeHTML(`
            <span class="toast-icon">${a}</span>
            <span class="toast-message">${e}</span>
            <button class="toast-close" onclick="this.parentElement.remove()">\u2715</button>
        `),s.appendChild(n),o>0&&setTimeout(()=>{n.parentElement&&(n.style.opacity="0",n.style.transform="translateY(-20px)",setTimeout(()=>{n.parentElement&&n.remove()},300))},o)}},ConfirmModal={_modal:null,_resolve:null,_isOpen:!1,show:function({title:e,message:t,confirmText:o="Confirm",cancelText:s="Cancel",showCancel:n=!0,thirdText:a=null,thirdColor:d="var(--c-secondary)",type:f="info",showInput:i=!1,inputType:r="textarea",required:w=!1,inputPlaceholder:I="Enter reason...",inputMaxLength:v=300,tipText:S="",icon:A=null,undismissable:B=!1,closeOnOverlayClick:E=!0,headerLayout:N="column",playersList:x=null}){return new Promise(j=>{this._resolve=j,this._undismissable=B,this._closeOnOverlayClick=E,this._modal||(this._modal=document.createElement("div"),this._modal.id="global-confirm-modal",this._modal.style.cssText=`
                    position:fixed; top:0; left:0; width:100%; height:100%;
                    background:rgba(0,0,0,0.8);
                    display:flex; flex-direction:column; align-items:center; justify-content:flex-start;
                    z-index:100000; opacity:0; pointer-events:none;
                    transition:opacity 0.25s ease; padding:32px 16px;
                    overflow-y:auto;
                `,document.body.appendChild(this._modal));const l=f==="warning",c=A??(l?"\u26A1":""),m=l?"var(--c-red)":"var(--c-primary)";let g="";if(i)if(r==="radio"){let p='<option value="" disabled selected hidden>Select Player</option>';x&&Array.isArray(x)&&x.forEach(u=>{p+=`<option value="${u.id}">${u.name}</option>`}),g=`
                        <div id="gcm-radio-container" style="margin-bottom:4px; width:100%; display:flex; flex-direction:column; align-items:flex-start;">
                            <label style="display:flex; align-items:center; gap:10px; margin-bottom:12px; cursor:pointer; color:#fff; font-size:14px; font-weight:600; text-align:left; width:100%;">
                                <input type="radio" name="gcm-radio-opt" value="No show" style="accent-color:var(--c-primary); width:18px; height:18px; cursor:pointer;" />
                                <span>No show</span>
                            </label>
                            
                            <label style="display:flex; align-items:center; gap:10px; margin-bottom:12px; cursor:pointer; color:#fff; font-size:14px; font-weight:600; text-align:left; width:100%;">
                                <input type="radio" name="gcm-radio-opt" value="Level mismatch" style="accent-color:var(--c-primary); width:18px; height:18px; cursor:pointer;" />
                                <span>Level mismatch</span>
                            </label>
                            
                            <label style="display:flex; align-items:center; gap:10px; margin-bottom:12px; cursor:pointer; color:#fff; font-size:14px; font-weight:600; text-align:left; width:100%;">
                                <input type="radio" name="gcm-radio-opt" value="Bad attitude" style="accent-color:var(--c-primary); width:18px; height:18px; cursor:pointer;" />
                                <span>Bad attitude</span>
                            </label>

                            ${x&&Array.isArray(x)?`
                            <div id="gcm-radio-player-wrap" style="display:none; margin-bottom:8px; width:100%; padding-left:28px; box-sizing:border-box;">
                                <label style="color:rgba(255,255,255,0.6); display:block; text-align:left; font-size:11px; font-weight:800; text-transform:uppercase; margin-bottom:6px; font-family:var(--font);">Select Player</label>
                                <select id="gcm-player-select" style="width:100%; border:1px solid rgba(255,255,255,0.15); background:rgba(23, 23, 28, 0.98) url(&quot;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='%238B9BB4' stroke-width='2'%3E%3Cpath d='M6 9l6 6 6-6'/%3E%3C/svg%3E&quot;) no-repeat right 16px center; appearance:none; -webkit-appearance:none; color:#fff; border-radius:12px; padding:14px 44px 14px 16px; font-size:14px; font-family:var(--font); outline:none; cursor:pointer;">
                                    ${p}
                                </select>
                            </div>
                            `:""}

                            <label style="display:flex; align-items:center; gap:10px; margin-bottom:12px; cursor:pointer; color:#fff; font-size:14px; font-weight:600; text-align:left; width:100%;">
                                <input type="radio" name="gcm-radio-opt" value="other" style="accent-color:var(--c-primary); width:18px; height:18px; cursor:pointer;" />
                                <span>Other</span>
                            </label>

                            <div id="gcm-radio-other-wrap" style="display:none; margin-bottom:8px; width:100%; padding-left:28px; box-sizing:border-box;">
                                <textarea id="gcm-input" placeholder="Please describe the issue..." maxlength="${v}" style="width:100%; border:1px solid rgba(255,255,255,0.15); background:rgba(255,255,255,0.06); color:#fff; border-radius:12px; padding:12px; font-size:14px; resize:none; font-family:var(--font); outline:none; margin-bottom:4px;" rows="3"></textarea>
                                <div style="display:flex; justify-content:space-between; margin-bottom:0; padding:0 4px;">
                                    <span id="gcm-tip" style="font-size:11px; color:var(--c-text-dim); text-align:left; flex:1; padding-right:10px;">${S}</span>
                                    <span id="gcm-counter" style="font-size:11px; color:var(--c-text-muted); font-weight:700; white-space:nowrap;">0/${v}</span>
                                </div>
                            </div>
                        </div>
                    `}else g=`
                        <${r==="textarea"?"textarea":"input"} id="gcm-input" type="${r}" placeholder="${I}" maxlength="${v}" style="width:100%; border:1px solid rgba(255,255,255,0.15); background:rgba(255,255,255,0.06); color:#fff; border-radius:12px; padding:12px; font-size:14px; margin-bottom:${r==="password"?"18px":"4px"}; resize:none; font-family:var(--font); outline:none;" ${r==="textarea"?'rows="6"':""}></${r==="textarea"?"textarea":"input"}>
                    `;i&&r!=="radio"&&(g+=`
                    <div style="display:${r==="password"?"none":"flex"}; justify-content:space-between; margin-bottom:24px; padding:0 4px;">
                        <span id="gcm-tip" style="font-size:11px; color:var(--c-text-dim); text-align:left; flex:1; padding-right:10px;">${S}</span>
                        <span id="gcm-counter" style="font-size:11px; color:var(--c-text-muted); font-weight:700; white-space:nowrap;">0/${v}</span>
                    </div>
                `);const P=a?`
                <button id="gcm-third" class="btn" style="background:${d}; color:white; border:none; padding:16px;">${a}</button>
            `:"",T=n?`
                <button id="gcm-cancel" class="btn" style="background:none; border:none; color:var(--c-text-muted); padding:12px; font-size:14px; font-weight:600;">${s}</button>
            `:"";let C="";if(N==="row")C=`
                    <div style="display:flex; align-items:flex-end; justify-content:flex-start; gap:10px; margin-bottom:16px; padding-bottom:16px; border-bottom:1px solid rgba(255,255,255,0.08);">
                        ${c?`<div style="font-size:24px; line-height:1;">${c}</div>`:""}
                        <h2 style="font-size:15px; font-weight:800; color:#fff; margin:0; text-transform:uppercase; letter-spacing:0.5px; line-height:1; padding-bottom:2px; text-align:left;">${e}</h2>
                    </div>
                `;else{let p="";c&&(p=`
                    <!-- Premium Emoji Frame -->
                    <div style="margin: 0 auto 20px; width:72px; height:72px; position:relative; display:flex; align-items:center; justify-content:center;">
                        <div style="position:absolute; inset:0; border-radius:50%; background:linear-gradient(135deg, var(--c-primary), #6366f1); opacity:0.15; filter:blur(10px);"></div>
                        <div style="position:absolute; inset:0; border-radius:50%; border:1px solid rgba(255,255,255,0.1); background:rgba(255,255,255,0.03);"></div>
                        <div style="font-size:34px; z-index:1; filter: drop-shadow(0 4px 10px rgba(0,0,0,0.3));">${c}</div>
                    </div>`),C=`
                    ${p}
                    <h2 style="font-size:22px; font-weight:700; background: linear-gradient(135deg, #ffffff 0%, #a5b4fc 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; margin-bottom:20px; letter-spacing:-0.5px; line-height:1.2; text-align:${c?"center":"left"};">${e}</h2>
                `}const h=N==="row",$=h?"380px":"340px",b=h?"20px":"28px",M=h?"24px":"32px";if(this._modal.innerHTML=safeHTML(`
                <div id="gcm-card" style="margin: auto 0; flex-shrink: 0; background:rgba(23, 23, 28, 0.98); backdrop-filter:blur(8px); border:1px solid rgba(255,255,255,0.1); border-radius:${M}; padding:${b}; width:100%; max-width:${$}; text-align:center; position:relative; transform:scale(0.85); opacity:0; transition:all 0.4s cubic-bezier(0.16, 1, 0.3, 1); box-shadow:0 30px 60px rgba(0,0,0,0.6);">
                    
                    ${C}
                    
                    ${g}
 
                    ${t?`<div style="font-size:12px; color:rgba(255,255,255,0.5); line-height:1.6; margin-bottom:24px; font-weight:400; text-align:left; padding:0;">${t.replace(/\n/g,"<br>")}</div>`:""}
 
                    <div style="display:flex; gap:12px; flex-direction:column;">
                        <button id="gcm-confirm" class="btn" style="background:var(--c-primary); color:#fff; border:none; width:100%; padding:14px; border-radius:16px; font-weight:800; font-size:14px; letter-spacing:0.5px; box-shadow: 0 8px 20px rgba(27, 82, 206, 0.25); transition:transform 0.2s;">
                            ${o.toUpperCase()}
                        </button>
                        ${P}
                        ${T}
                    </div>
                </div>
            `),this._modal.onclick=p=>{p.target===this._modal&&!this._undismissable&&this._closeOnOverlayClick&&this.close(!1)},this._modal.querySelector("#gcm-confirm").onclick=()=>{let p=null;if(i)if(r==="radio"){const u=this._modal.querySelector('input[name="gcm-radio-opt"]:checked');if(!u){Toast.show("Please select an option.","error");return}const _=u.value;if(_==="other"){const y=this._modal.querySelector("#gcm-input").value.trim();if(y===""){this._modal.querySelector("#gcm-input").style.borderColor="var(--c-red)",Toast.show("Please describe the issue.","error");return}p="Other: "+y}else{if(x&&Array.isArray(x)){const y=this._modal.querySelector("#gcm-player-select");if(!y||y.value===""){Toast.show("Please select a player.","error");return}}p=_}}else{const u=this._modal.querySelector("#gcm-input").value.trim();if(w&&u===""){const _=this._modal.querySelector("#gcm-input");_.style.borderColor="var(--c-red)";const y=r==="password"?"Please enter your password.":"Please enter a message.";Toast.show(y,"error");return}p=u}else p=!0;if(x&&Array.isArray(x)){const u=this._modal.querySelector('input[name="gcm-radio-opt"]:checked'),_=u&&u.value==="other",y=this._modal.querySelector("#gcm-player-select"),k=!_&&y?parseInt(y.value):null;this.close({reason:p,targetUserId:k})}else this.close(p)},i){const p=this._modal.querySelector("#gcm-input"),u=this._modal.querySelector("#gcm-counter");if(r==="radio"){const _=this._modal.querySelectorAll('input[name="gcm-radio-opt"]'),y=this._modal.querySelector("#gcm-radio-other-wrap"),k=this._modal.querySelector("#gcm-radio-player-wrap");_.forEach(O=>{O.onchange=()=>{const H=O.closest("label");O.value==="other"?(y.style.display="block",k&&(k.style.display="none"),setTimeout(()=>p.focus(),100)):(y.style.display="none",k&&(k.style.display="block",H.parentNode.insertBefore(k,H.nextSibling)))}})}p.oninput=()=>{u&&(u.innerText=`${p.value.length}/${v}`),p.style.borderColor="var(--c-border)"},r!=="radio"&&setTimeout(()=>p.focus(),300)}a&&(this._modal.querySelector("#gcm-third").onclick=()=>this.close("third"));const z=this._modal.querySelector("#gcm-cancel");z&&(z.onclick=()=>this.close(!1));const L=window.scrollY||document.documentElement.scrollTop;document.documentElement.style.overflow="hidden",document.body.style.overflow="hidden",document.body.style.position="fixed",document.body.style.top=`-${L}px`,document.body.style.width="100%",this._isOpen=!0,this._modal.style.opacity="1",this._modal.style.pointerEvents="auto",setTimeout(()=>{const p=document.getElementById("gcm-card");p&&(p.style.transform="scale(1)",p.style.opacity="1")},10)})},close:function(e){if(!this._modal)return;if(this._undismissable){if(this._resolve){const s=this._resolve;this._resolve=null,s(e)}return}const t=parseFloat(document.body.style.top||"0")*-1;document.documentElement.style.overflow="",document.body.style.overflow="",document.body.style.touchAction="",document.body.style.position="",document.body.style.top="",document.body.style.width="",this._modal.ontouchmove=null,t>0&&window.scrollTo(0,t),this._isOpen=!1,this._modal.style.opacity="0",this._modal.style.pointerEvents="none";const o=document.getElementById("gcm-card");o&&(o.style.transform="scale(0.95)",o.style.opacity="0"),setTimeout(()=>{this._resolve&&this._resolve(e)},250)}},InviteModal={_modal:null,_isOpen:!1,show:function(e,t){this._modal||(this._modal=document.createElement("div"),this._modal.id="invite-modal-overlay",this._modal.style.cssText=`
                position:fixed; top:0; left:0; width:100%; height:100%;
                background:rgba(0,0,0,0.8);
                display:flex; flex-direction:column; align-items:center; justify-content:flex-start;
                z-index:100000; opacity:0; pointer-events:none;
                transition:opacity 0.25s ease; padding:32px 16px;
                overflow-y:auto;
            `,document.body.appendChild(this._modal));const o=e.map((n,a)=>{const d=!!n.used_at;let f="";if(d){let i="?";n.used_by_name&&(i=n.used_by_name.substring(0,2).toUpperCase()),f=`
                    <div style="display:flex; align-items:center; gap:10px; width:100%;">
                        ${UI.getAvatarHtml(n.used_by_avatar,"width:100%; height:100%; border-radius:50%; object-fit:cover;","width:32px; height:32px; border-radius:50%; flex-shrink:0; font-size:11px; font-weight:700; display:flex; align-items:center; justify-content:center; background:rgba(255,255,255,0.06); color:#fff;",i)}
                        <div style="flex:1; text-align:left; min-width:0;">
                            <div style="font-weight:700; font-size:13px; color:#fff; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">Used by ${n.used_by_name}</div>
                            <div style="font-size:10px; color:var(--c-orange); font-weight:800; font-family:monospace; margin-top:2px;">CODE: ${n.code}</div>
                        </div>
                        <span style="font-size:18px; color:var(--c-green); flex-shrink:0;">\u2713</span>
                    </div>
                `}else f=`
                    <div style="display:flex; align-items:center; justify-content:space-between; width:100%;">
                        <span style="font-family: 'JetBrains Mono', monospace; font-size:15px; font-weight:800; color:#fff; letter-spacing:0.5px;">${n.code}</span>
                        <button onclick="InviteModal.copyCode('${n.code}', this)" class="btn btn-sm" style="background:rgba(255,255,255,0.05); color:#fff; border:1px solid rgba(255,255,255,0.1); padding:6px 14px; border-radius:8px; font-size:11px; font-weight:700; transition:all 0.2s; cursor:pointer;" onmouseover="this.style.background='rgba(255,255,255,0.1)'" onmouseout="this.style.background='rgba(255,255,255,0.05)'">
                            COPY
                        </button>
                    </div>
                `;return`
                <div style="display:flex; align-items:center; background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); border-radius:16px; padding:14px 18px; margin-bottom:12px; transition:all 0.2s;">
                    ${f}
                </div>
            `}).join("");this._modal.innerHTML=safeHTML(`
             <div id="invite-modal-card" style="margin: auto 0; background:rgba(23, 23, 28, 0.98); backdrop-filter:blur(8px); border:1px solid rgba(255,255,255,0.1); border-radius:32px; padding:28px; width:100%; max-width:340px; text-align:center; position:relative; transform:scale(0.85); opacity:0; transition:all 0.4s cubic-bezier(0.16, 1, 0.3, 1); box-shadow:0 30px 60px rgba(0,0,0,0.6);">
                <div style="margin: 0 auto 20px; width:72px; height:72px; position:relative; display:flex; align-items:center; justify-content:center;">
                    <div style="position:absolute; inset:0; border-radius:50%; background:linear-gradient(135deg, var(--c-orange), #ff8b00); opacity:0.15; filter:blur(10px);"></div>
                    <div style="position:absolute; inset:0; border-radius:50%; border:1px solid rgba(255,255,255,0.1); background:rgba(255,255,255,0.03);"></div>
                    <div style="font-size:34px; z-index:1; filter: drop-shadow(0 4px 10px rgba(0,0,0,0.3));">\u{1F39F}\uFE0F</div>
                </div>
                <h2 style="font-size:20px; font-weight:900; color:#fff; margin-bottom:8px; letter-spacing:-0.5px; line-height:1.2;">Exclusive Invites</h2>
                <p style="font-size:12px; color:var(--c-text-muted); line-height:1.6; margin-bottom:24px; font-weight:400; padding:0 8px; text-align:center;">
                    Your friends need one of these exclusive codes to register. Give them out wisely!
                </p>

                <div style="margin-bottom:24px;">
                    ${o}
                </div>

                <div>
                    <button onclick="InviteModal.close()" class="btn" style="background:var(--c-primary); color:#fff; border:none; width:100%; padding:14px; border-radius:16px; font-weight:800; font-size:14px; letter-spacing:0.5px; box-shadow: 0 8px 20px rgba(27, 82, 206, 0.25); transition:transform 0.2s;">
                        CLOSE
                    </button>
                </div>
            </div>
        `),this._modal.onclick=n=>{n.target===this._modal&&this.close()};const s=window.scrollY||document.documentElement.scrollTop;document.documentElement.style.overflow="hidden",document.body.style.overflow="hidden",document.body.style.position="fixed",document.body.style.top=`-${s}px`,document.body.style.width="100%",this._isOpen=!0,this._modal.style.opacity="1",this._modal.style.pointerEvents="auto",setTimeout(()=>{const n=document.getElementById("invite-modal-card");n&&(n.style.transform="scale(1)",n.style.opacity="1")},10)},copyCode:function(e,t){if(!navigator.clipboard){const o=document.createElement("textarea");o.value=e,o.style.position="fixed",document.body.appendChild(o),o.focus(),o.select();try{document.execCommand("copy"),this.onCopySuccess(t)}catch(s){console.error("Fallback copy failed",s)}document.body.removeChild(o);return}navigator.clipboard.writeText(e).then(()=>{this.onCopySuccess(t)}).catch(o=>{console.error("Clipboard copy failed",o)})},onCopySuccess:function(e){if(e){const t=e.textContent;e.textContent="COPIED!",e.style.borderColor="var(--c-green)",e.style.color="var(--c-green)",e.style.background="rgba(16,185,129,0.1)",setTimeout(()=>{e.textContent=t,e.style.borderColor="rgba(255,255,255,0.1)",e.style.color="#fff",e.style.background="rgba(255,255,255,0.05)"},2e3)}Toast.show("Invitation code copied to clipboard!","success")},close:function(){if(!this._modal)return;const e=parseFloat(document.body.style.top||"0")*-1;document.documentElement.style.overflow="",document.body.style.overflow="",document.body.style.touchAction="",document.body.style.position="",document.body.style.top="",document.body.style.width="",e>0&&window.scrollTo(0,e),this._isOpen=!1,this._modal.style.opacity="0",this._modal.style.pointerEvents="none";const t=document.getElementById("invite-modal-card");t&&(t.style.transform="scale(0.95)",t.style.opacity="0")}},PollManager={_timer:null,_activeTask:null,start:function(e,t,o=15e3){this.stop(),this._activeTask=e,this._timer=setInterval(()=>{console.log(`[PollManager] Running: ${e}`),t()},o)},stop:function(){this._timer&&(console.log(`[PollManager] Stopping: ${this._activeTask}`),clearInterval(this._timer),this._timer=null,this._activeTask=null)}},PushNotificationsController={_isStartingUp:!0,init:async function(){const e=window.Capacitor?.Plugins?.PushNotifications;if(!e){console.log("[PushNotifications] Not a native app or plugin missing");return}setTimeout(()=>{this._isStartingUp=!1,console.log("[PushNotifications] Startup silence period ended")},3e3),await new Promise(t=>setTimeout(t,2e3));try{console.log("[PushNotifications] Starting registration flow...");let t=await e.checkPermissions();if(console.log("[PushNotifications] Permission status:",t.receive),t.receive==="prompt"&&(t=await e.requestPermissions()),t.receive!=="granted"){console.log("[PushNotifications] Permission not granted");return}console.log("[PushNotifications] Registering..."),await e.register(),this.setupListeners(e)}catch(t){console.error("[PushNotifications] Initialization crash prevented:",t)}},setupListeners:function(e){if(e)try{e.addListener("registration",t=>{console.log("[PushNotifications] Registration success"),this.updateServerToken(t.value)}),e.addListener("registrationError",t=>{console.error("[PushNotifications] Registration error:",t.error)}),e.addListener("pushNotificationReceived",t=>{console.log("[PushNotifications] Received in foreground:",t),t.title&&t.body&&(Toast.show(t.body,"info"),typeof SoundManager<"u"&&!this._isStartingUp&&SoundManager.play("notify"),typeof Router<"u"&&Router.currentPath==="/dashboard"&&typeof DashboardController<"u"&&DashboardController.load())}),e.addListener("pushNotificationActionPerformed",t=>{console.log("[PushNotifications] Action performed. App opened via notification.")})}catch(t){console.error("[PushNotifications] Listener setup failed:",t)}},updateServerToken:async function(e){if(typeof Auth<"u"&&!Auth.isAuthenticated())return;const t=window.Capacitor?.getPlatform?.()||"web";console.log("[PushNotifications] Updating server token..."),await API.post("/profile/update_device_token",{token:e,platform:t})}};const InAppMessagesController={init:async function(){Auth.isAuthenticated()&&this.check()},check:async function(){try{const e=await API.get("/system/check_in_app_messages?t="+Date.now());e.success&&e.data&&this.display(e.data)}catch(e){console.error("[InAppMessages] Check failed:",e)}},display:async function(e){let t=e.button_text||"Got it",o=e.action_type;ConfirmModal.show({title:e.heading,message:e.body,icon:e.emoji,confirmText:t,showCancel:!1,type:"info",undismissable:e.is_undismissable==1,closeOnOverlayClick:!1}).then(async s=>{if(await API.post("/system/mark_message_seen",{message_id:e.id}),!!s){if(o==="navigate"&&e.page_route)Router.navigate(e.page_route);else if(o==="external"){const n=window.Capacitor?.getPlatform?.()||"web";let a=e.android_url;n==="ios"&&(a=e.ios_url||e.android_url),a&&window.open(a,"_blank")}}})}},ScoreUI={renderMatchScore:function(e,t=null,o=null,s=!0,n=null){if(!t&&e.scores&&(t=e.scores.find(l=>l.status==="approved")),!t)return"";const a=[];let d=0,f=0;for(let l=1;l<=3;l++){const c=parseInt(t[`t1_set${l}`]),m=parseInt(t[`t2_set${l}`]);if(isNaN(c)||isNaN(m)||l>1&&c===0&&m===0)continue;const g=c>m?1:m>c?2:0;g===1?d++:g===2&&f++,a.push({s1:c,s2:m,winner:g})}const i=d>f;let r=[],w=[];const I=o||[...e.team_a||[],...e.team_b||[]];let v=null;if(t.composition_json)try{v=typeof t.composition_json=="string"?JSON.parse(t.composition_json):t.composition_json}catch{}v&&v.length>0?v.forEach(l=>{const c=I.find(g=>parseInt(g.user_id||g.id)===parseInt(l.user_id)),m={name:l.nickname||l.name||(c?c.nickname||c.name||c.first_name+" "+c.last_name:"\u2014"),code:l.player_code||l.code||(c?c.player_code||c.code:""),team_no:parseInt(l.team_no),user_id:parseInt(l.user_id),point_change:c?.point_change??null};m.team_no===1?r.push(m):m.team_no===2&&w.push(m)}):I.forEach(l=>{const c={name:l.nickname||l.name||l.first_name+" "+l.last_name||"\u2014",code:l.player_code||l.code||"",team_no:parseInt(l.team_no),user_id:parseInt(l.user_id||l.id),point_change:l.point_change??null};c.team_no===1?r.push(c):c.team_no===2&&w.push(c)});const S=(l,c)=>{const m=l[0]||{name:"\u2014"},g=l[1]||{name:"\u2014"},P=e.match_type==="friendly",T=P?"#5A91FF":"var(--c-orange)",C=h=>{let $="";if(n&&parseInt(h.user_id)===parseInt(n)&&h.point_change!==null&&h.point_change!==void 0){const b=parseInt(h.point_change);if(b!==0&&!isNaN(b)){const M=b>0?"#064e3b":"#450a0a",z=b>0?"#4ade80":"#f87171",L=b>0?"1px solid rgba(74,222,128,0.4)":"1px solid rgba(248,113,113,0.4)",p=b>0?"\u2191":"\u2193";$=`<span style="font-size:10px; font-weight:700; letter-spacing:0.3px; background:${M}; color:${z}; padding:0 6px; border-radius:10px; border:${L}; box-shadow:0 2px 6px rgba(0,0,0,0.4); white-space:nowrap; display:inline-flex; align-items:center; height:18px; line-height:1; margin-left:3px; vertical-align:middle;"><span style="font-size:11px; margin-right:2px; font-weight:800;">${p}</span>${Math.abs(b)}</span>`}}return`<span class="msc-premium-player-name">${h.name}</span>${$}`};return`
                <div class="msc-premium-row" style="opacity:${c?"1":"0.85"}; background:${c?P?"rgba(90,145,255,0.06)":"rgba(247,148,29,0.06)":"transparent"};">
                    <div class="msc-premium-players" style="font-weight:${c?"700":"400"}; color:${c?"#fff":"rgba(255,255,255,0.8)"};">
                        ${C(m)}
                        <span style="opacity:0.25; margin:0 4px;">/</span>
                        ${C(g)}
                    </div>
                    <div class="msc-premium-scores">
                        ${a.map(h=>{const $=h.winner===(l===r?1:2),b=l===r?h.s1:h.s2;return`
                                <span class="msc-premium-score-val" style="color:${$?T:"rgba(255,255,255,0.35)"};">
                                    ${b}
                                </span>
                            `}).join("")}
                    </div>
                </div>
            `},A=(e.venue||"Venue TBD").split(" - ")[0].trim(),B=e.scheduled_at?new Date(e.scheduled_at.replace(" ","T")).toLocaleDateString("en-US",{weekday:"short",day:"numeric",month:"short"}):"",E=e.match_type==="friendly",x=s?`
            <div class="msc-premium-header">
                <span class="msc-premium-venue-date">${A} \u2022 ${B}</span>
                <span class="msc-premium-type-badge" style="color:${E?"#5A91FF":"var(--c-orange)"};">
                    ${E?"\u{1F91D} Friendly":"\u{1F3C6} Competition"}
                </span>
            </div>
        `:"",j=E?"#5A91FF":"var(--c-orange)";return`
            <div class="msc-premium-card">
                ${x}
                <div class="msc-premium-body">
                    ${S(r,i)}
                    ${S(w,!i)}
                </div>
            </div>
        `},renderSkeleton:function(e=3){let t="";for(let o=0;o<e;o++)t+=`
                <div style="margin-bottom:12px; padding:16px; background:rgba(255,255,255,0.02); border-radius:var(--r-lg); border:1px solid rgba(255,255,255,0.05); overflow:hidden;">
                    <div style="display:flex; align-items:center; gap:8px; margin-bottom:16px; padding:0 4px;">
                        <div class="skeleton" style="width:80px; height:10px; border-radius:4px; opacity:0.6;"></div>
                        <div style="width:4px; height:4px; border-radius:50%; background:var(--c-border); opacity:0.3;"></div>
                        <div class="skeleton" style="width:60px; height:10px; border-radius:4px; opacity:0.4;"></div>
                    </div>
                    <div style="display:flex; flex-direction:column; gap:8px;">
                        <div style="display:flex; justify-content:space-between; align-items:center; background:rgba(255,255,255,0.01); padding:10px 12px; border-radius:10px; border:1px solid rgba(255,255,255,0.02);">
                            <div style="display:flex; align-items:center; gap:8px;">
                                <div style="width:10px; height:10px; border-radius:2px; background:var(--c-border); opacity:0.2;"></div>
                                <div style="display:flex; gap:6px;">
                                    <div class="skeleton" style="width:90px; height:12px; border-radius:4px;"></div>
                                    <div class="skeleton" style="width:36px; height:12px; border-radius:4px; opacity:0.5;"></div>
                                </div>
                            </div>
                            <div style="display:flex; gap:10px;">
                                <div class="skeleton" style="width:14px; height:16px; border-radius:4px; opacity:0.8;"></div>
                                <div class="skeleton" style="width:14px; height:16px; border-radius:4px; opacity:0.4;"></div>
                            </div>
                        </div>
                        <div style="display:flex; justify-content:space-between; align-items:center; background:rgba(255,255,255,0.01); padding:10px 12px; border-radius:10px; border:1px solid rgba(255,255,255,0.02);">
                            <div style="display:flex; align-items:center; gap:8px;">
                                <div style="width:10px; height:10px; border-radius:2px; background:transparent;"></div>
                                <div style="display:flex; gap:6px;">
                                    <div class="skeleton" style="width:110px; height:12px; border-radius:4px;"></div>
                                    <div class="skeleton" style="width:36px; height:12px; border-radius:4px; opacity:0.5;"></div>
                                </div>
                            </div>
                            <div style="display:flex; gap:10px;">
                                <div class="skeleton" style="width:14px; height:16px; border-radius:4px; opacity:0.4;"></div>
                                <div class="skeleton" style="width:14px; height:16px; border-radius:4px; opacity:0.8;"></div>
                            </div>
                        </div>
                    </div>
                </div>
            `;return t}},RankingUI={renderSkeleton:function(e=5){let t="";for(let o=0;o<e;o++)t+=`
                <div style="padding:14px 10px; display:grid; grid-template-columns: 40px 1fr 60px; align-items:center; gap:12px; border-bottom:1px solid rgba(255,255,255,0.05); overflow:hidden;">
                    <div style="display:flex; justify-content:center;">
                        <div class="skeleton" style="width:24px; height:24px; border-radius:50%; opacity:0.3;"></div>
                    </div>
                    <div style="display:flex; align-items:center; gap:12px;">
                        <div class="skeleton" style="width:36px; height:36px; border-radius:50%; flex-shrink:0;"></div>
                        <div style="display:flex; flex-direction:column; gap:6px; flex:1;">
                            <div class="skeleton" style="width:120px; height:12px; border-radius:4px;"></div>
                            <div class="skeleton" style="width:80px; height:10px; border-radius:4px; opacity:0.5;"></div>
                        </div>
                    </div>
                    <div style="display:flex; justify-content:flex-end;">
                        <div class="skeleton" style="width:40px; height:14px; border-radius:4px;"></div>
                    </div>
                </div>
            `;return t}},StatsUI={update:function(e,t){if(!e)return;const o=()=>{const i=document.createElementNS("http://www.w3.org/2000/svg","svg");i.setAttribute("width","12"),i.setAttribute("height","12"),i.setAttribute("viewBox","0 0 24 24"),i.setAttribute("fill","none"),i.setAttribute("stroke","currentColor"),i.setAttribute("stroke-width","4"),i.setAttribute("stroke-linecap","round"),i.setAttribute("stroke-linejoin","round");const r=document.createElementNS("http://www.w3.org/2000/svg","polyline");return r.setAttribute("points","18 15 12 9 6 15"),i.appendChild(r),i},s=()=>{const i=document.createElementNS("http://www.w3.org/2000/svg","svg");i.setAttribute("width","12"),i.setAttribute("height","12"),i.setAttribute("viewBox","0 0 24 24"),i.setAttribute("fill","none"),i.setAttribute("stroke","currentColor"),i.setAttribute("stroke-width","4"),i.setAttribute("stroke-linecap","round"),i.setAttribute("stroke-linejoin","round");const r=document.createElementNS("http://www.w3.org/2000/svg","polyline");return r.setAttribute("points","6 9 12 15 18 9"),i.appendChild(r),i},n={ranking:e.ranking??"\u2014",points:e.points,matches:e.matches_played,winrate:e.win_rate+"%"};for(const[i,r]of Object.entries(n)){const w=document.getElementById(`${t}-${i}`)||document.getElementById(`${t}-${i}-count`);w&&(w.innerHTML="",w.textContent=r)}const a=document.getElementById(`${t}-ranking-change`)||document.getElementById(`${t}-highest-rank`);if(a){a.innerHTML="";const i=document.createElement("span");e.ranking_change>0?(i.className="stat-trend up",i.appendChild(o()),i.append(` ${e.ranking_change} POSITIONS`)):e.ranking_change<0?(i.className="stat-trend down",i.appendChild(s()),i.append(` ${Math.abs(e.ranking_change)} POSITIONS`)):(i.className="stat-trend neutral",i.textContent="STABLE RANK"),a.appendChild(i)}const d=document.getElementById(`${t}-points-week`);if(d){d.innerHTML="";const i=e.current_buffer??0;if(i>0){const r=document.createElement("span");r.style.cssText="color: var(--c-orange); background: rgba(255, 139, 0, 0.12); border: 1px solid rgba(255, 139, 0, 0.25); padding: 3px 8px; border-radius: 6px; display: inline-flex; align-items: baseline; gap: 6px;",r.innerHTML=`<span style="font-size: 13px; font-weight: 800;">+${i}</span><span style="font-size: 9px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px;">BUFFER</span>`,d.appendChild(r),d.style.color=""}else if(e.points_this_week!==void 0){if(e.points_this_week>0){const r=document.createElement("span");r.className="stat-trend up",r.appendChild(o()),r.append(` +${e.points_this_week} THIS WEEK`),d.appendChild(r),d.style.color=""}else if(e.points_this_week<0){const r=document.createElement("span");r.className="stat-trend down",r.appendChild(s()),r.append(` ${e.points_this_week} THIS WEEK`),d.appendChild(r),d.style.color=""}}}const f=document.getElementById(`${t}-wl`);f&&e.matches_played>0&&(f.innerHTML=safeHTML(`<span style="color:#4ebd79;">${e.matches_won}W</span> <span style="opacity:0.85; margin:0 3px;">/</span> <span style="color:#e57373;">${e.matches_lost}L</span>`),f.style.fontSize="11px",f.style.fontWeight="500",f.style.letterSpacing="0.5px")}};document.addEventListener("DOMContentLoaded",()=>{Auth.init().then(()=>Auth.syncWithServer()).then(()=>{Router.init(),NotificationsController.init(),SoundManager.init(),typeof Auth<"u"&&Auth.isAuthenticated()&&(PushNotificationsController.init(),InAppMessagesController.init(),typeof UI<"u"&&UI.syncNav&&UI.syncNav())});const e=window.Capacitor?.Plugins?.StatusBar;e&&(e.setBackgroundColor({color:"#0D1117"}),e.setStyle({style:"DARK"}));const t=window.Capacitor?.Plugins?.App;if(t&&(t.addListener("appStateChange",({isActive:o})=>{!o&&typeof ChatController<"u"&&ChatController._isShowing&&ChatController._matchId?ChatController.stop():o&&typeof ChatController<"u"&&ChatController._isShowing&&ChatController._matchId&&setTimeout(()=>{navigator.onLine&&(ChatController.startPoll(),ChatController.loadMessages(!1))},300)}),t.addListener("appUrlOpen",o=>{if(console.log("[App] Deep link received:",o.url),o.url){const n=new URL(o.url).pathname;if(n&&n.startsWith("/matches/")){const a=n.split("/matches/");if(a[1]){const d=a[1].trim();console.log("[App] Routing to deep linked match:",d),typeof Router<"u"&&Router.navigate("/matches/"+d,!0,!0)}}}}),t.addListener("backButton",()=>{if(typeof ConfirmModal<"u"&&ConfirmModal._isOpen){ConfirmModal.close(!1);return}if(document.getElementById("scoring-modal-overlay")&&typeof ScoringController<"u"){ScoringController.closeModal();return}if(typeof InviteModal<"u"&&InviteModal._isOpen){InviteModal.close();return}if(typeof StoriesController<"u"&&StoriesController._isShowing){StoriesController.closePlayer();return}if(typeof NotificationsController<"u"&&NotificationsController._isOpen){NotificationsController.close();return}Router.navDepth>0?Router.back():t.exitApp()})),window.Capacitor){document.body.classList.add("is-mobile-app");const o=window.Capacitor?.getPlatform?.()||"web";o&&document.body.classList.add(`platform-${o}`);const s=document.createElement("style");s.textContent=`
            *::-webkit-scrollbar { display: none !important; width: 0 !important; height: 0 !important; background: transparent !important; }
            *::-webkit-scrollbar-thumb { display: none !important; background: transparent !important; }
            *::-webkit-scrollbar-track { display: none !important; background: transparent !important; }
            html, body { scrollbar-width: none !important; -ms-overflow-style: none !important; }
        `,document.head.appendChild(s);const n=window.Capacitor?.Plugins?.CapacitorUpdater;n&&(n.notifyAppReady().catch(a=>console.log("notifyAppReady:",a)),n.download().then(a=>{a&&n.set(a).catch(d=>console.log("set version err:",d))}).catch(a=>console.log("download check err:",a)))}document.addEventListener("click",o=>{const s=o.target.closest(".password-toggle");if(!s)return;o.preventDefault();const n=s.closest(".password-wrap");if(!n)return;const a=n.querySelector("input");if(!a)return;const d=a.getAttribute("type")==="password";a.setAttribute("type",d?"text":"password"),d?s.innerHTML=`
                <svg viewBox="0 0 24 24" width="${s.querySelector("svg").getAttribute("width")}" height="${s.querySelector("svg").getAttribute("height")}" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="eye-icon">
                    <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path>
                    <line x1="1" y1="1" x2="23" y2="23"></line>
                </svg>
            `:s.innerHTML=`
                <svg viewBox="0 0 24 24" width="${s.querySelector("svg").getAttribute("width")}" height="${s.querySelector("svg").getAttribute("height")}" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="eye-icon">
                    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                    <circle cx="12" cy="12" r="3"></circle>
                </svg>
            `})});
